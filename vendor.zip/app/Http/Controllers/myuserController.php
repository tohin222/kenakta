<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Hash;
use Auth;
use App\User;

class myuserController extends Controller
{
    public function profile(){
        return view('backend.user.index');
    }
    public function edit(){
        return view('backend.user.edit');
    }
    public function update(Request $request){
       // dd($request->all());
        //echo "hghy";
        // return view('backend.user.edit');
        if(Hash::check($request->password,Auth::user()->password)){
            User::find(Auth::user()->id)->update([
                'name'=> $request->name,
                'password'=> bcrypt($request->new_password)
            ]);
        }
        return redirect()->route('profile');
    }
}
