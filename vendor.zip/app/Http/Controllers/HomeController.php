<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Contact;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('backend.home');
    }
    public function backend_contact()
    {
        $mycontacts = Contact::all();
        return view('backend.contact',compact('mycontacts'));
    }
    public function contact_delete($id)
    {
        Contact::where('id',$id)->delete();
        return back()->with('success','Client Delete Succesfully');
    }
}
