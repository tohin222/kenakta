<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Team;
use Carbon\Carbon;

class teamController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
         $teams = Team::all();
        return view('backend.team.index',compact('teams'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('backend.team.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'name' => 'required|',
            'post' => 'required'

          ]);
          if($request->hasFile('image')){
            $post_id =  Team::insertGetId([
              'name'    =>$request->name,
              'post'    =>$request->post,
              'created_at' => Carbon::now(),
            ]);
            $path = $request->file('image')->store('image');
            Team::find($post_id)->update([
              'image'=> $path
            ]);
            return back()->with('success','Banner add Succesfully');
          }
          else{
            Team::insert([
                'name'    =>$request->name,
              'post'    =>$request->post,
              'created_at' => Carbon::now(),
            ]);
            return back()->with('success','Banner add Succesfully');
          }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $team = Team::findOrFail($id);
        return view('backend.team.edit',compact('team'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validatedData = $request->validate([
            'name' => 'required|',
            'post' => 'required'

          ]);
        $id = $request->id;
        if($request->hasFile('image')){
           Team::where('id',$id)->update([
            'name'    =>$request->name,
            'post'    =>$request->post,
            'created_at' => Carbon::now(),
          ]);
          $path = $request->file('image')->store('image');
          Team::find($id)->update([
            'image'=> $path
          ]);
          return redirect()->route('team.index')->with('success','Team update Succesfully');
        }
        else{
            Team::where('id',$id)->update([
                'name'    =>$request->name,
                'post'    =>$request->post,
                'created_at' => Carbon::now(),
          ]);
          return redirect()->route('team.index')->with('success','Team update Succesfully');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
      Team::where('id',$id)->delete();
      return back()->with('success','Team Delete Succesfully');
    }
}
