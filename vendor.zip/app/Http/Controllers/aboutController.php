<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Header;

class aboutController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function about(){
        $headers = Header::all();

        return view('frontend.about',compact('headers'));
    }
}
