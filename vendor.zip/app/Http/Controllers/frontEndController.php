<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Banner;
use App\Header;
use App\Team;
use App\Client;
use App\Portfolio;

class frontEndController extends Controller
{
    public function banner(){
        $banners = Banner::all();
        $headers = Header::all();
        $teams = Team::all();
        $myclients = Client::all();
        $portfolios = Portfolio::all();
        return view('frontend.welcome',compact('banners','headers','teams','myclients','portfolios'));
    }
    public function contact()
    {
        $headers = Header::all();

        return view('frontend.contact',compact('headers'));
    }
}
