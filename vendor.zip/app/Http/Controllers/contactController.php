<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Header;
use App\Contact;

class contactController extends Controller
{
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'name' => 'required',
            'email' => 'required',
            'phone' => 'required',
            'subject' => 'required',
            'message' => 'required',
        ]);
        Contact::create($request->all());
        return back();
    }
}
