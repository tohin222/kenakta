<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Portfolio;
use Carbon\Carbon;

class portfolioController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $portfolies = Portfolio::all();
        return view('backend.portfolio.index',compact('portfolies'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('backend.portfolio.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'name' => 'required|',
            'link' => 'required',
            'classname' => 'required'

          ]);
          if($request->hasFile('image')){
            $post_id =  Portfolio::insertGetId([
              'name'    =>$request->name,
              'link'    =>$request->link,
              'classname'    =>$request->classname,
              'created_at' => Carbon::now(),
            ]);
            $path = $request->file('image')->store('image');
            Portfolio::find($post_id)->update([
              'image'=> $path
            ]);
            return back()->with('success','Portfolio add Succesfully');
          }
          else{
            Portfolio::insert([
                'name'    =>$request->name,
                'link'    =>$request->link,
                'classname'    =>$request->classname,
                'created_at' => Carbon::now(),
            ]);
            return back()->with('success','Portfolio add Succesfully');
          }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $portfolio = Portfolio::findOrFail($id);
        return view('backend.portfolio.edit',compact('portfolio'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validatedData = $request->validate([
            'name' => 'required|',
            'link' => 'required',
            'classname' => 'required'

          ]);
        $id = $request->id;
        if($request->hasFile('image')){
            Portfolio::where('id',$id)->update([
            'name'    =>$request->name,
            'link'    =>$request->link,
            'classname'    =>$request->classname,
            'created_at' => Carbon::now(),
          ]);
          $path = $request->file('image')->store('image');
          Portfolio::find($id)->update([
            'image'=> $path
          ]);
          return redirect()->route('portfolio.index')->with('success','portfolio update Succesfully');
        }
        else{
            Portfolio::where('id',$id)->update([
                'name'    =>$request->name,
                'link'    =>$request->link,
                'classname'    =>$request->classname,
                'created_at' => Carbon::now(),
          ]);
          return redirect()->route('portfolio.index')->with('success','portfolio update Succesfully');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Portfolio::where('id',$id)->delete();
        return back()->with('success','portfolio Delete Succesfully');
    }
}
