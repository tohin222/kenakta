<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Banner;
use Carbon\Carbon;

class bannerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index()
    {
        $banners = Banner::all();
        return view('backend.banner.index',compact('banners'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('backend.banner.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'title' => 'required|',
            'content' => 'required'

          ]);
          if($request->hasFile('image')){
            $banner_id =  Banner::insertGetId([
              'title'    =>$request->title,
              'content'    =>$request->content,
              'created_at' => Carbon::now(),
            ]);
            $path = $request->file('image')->store('image');
            Banner::find($banner_id)->update([
              'image'=> $path
            ]);
            return back()->with('success','Banner add Succesfully');
          }
          else{
            Banner::insert([
                'title'    =>$request->title,
              'content'    =>$request->content,
              'created_at' => Carbon::now(),
            ]);
            return back()->with('success','Banner add Succesfully');
          }
    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $banner = Banner::findOrFail($id);
        return view('backend.banner.edit',compact('banner'));

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    
    public function update(Request $request, $id)
    {
        $validatedData = $request->validate([
            'title' => 'required|',
            'content' => 'required'

          ]);
        $id = $request->id;
        if($request->hasFile('image')){
           Banner::where('id',$id)->update([
            'title'    =>$request->title,
            'content'    =>$request->content,
            'created_at' => Carbon::now(),
          ]);
          $path = $request->file('image')->store('image');
          Banner::find($id)->update([
            'image'=> $path
          ]);
          return redirect()->route('banner.index')->with('success','Banner update Succesfully');
        }
        else{
            Banner::where('id',$id)->update([
                'title'    =>$request->title,
                'content'    =>$request->content,
                'created_at' => Carbon::now(),
          ]);
          return redirect()->route('banner.index')->with('success','Banner update Succesfully');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        banner::where('id',$id)->delete();
        return back()->with('success','Banner Delete Succesfully');
    }
}
