<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Header extends Model
{
    use SoftDeletes;
    protected $fillable = [
        'facebook', 'linkdin', 'twitter','pinterest', 'google', 'number',
    ];

    protected $dates = ['deleted_at'];
}





