<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Portfolio extends Model
{
    use SoftDeletes;
    protected $fillable = [
        'name','link', 'classname','image',
    ];

    protected $dates = ['deleted_at'];
}




