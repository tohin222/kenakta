<div class="sup_testimonial_section sup_testimonial_section2 sup_toppadder100 sup_bottompadder100">
    <div class="sup_overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-8 col-sm-12 col-xs-12 col-lg-offset-3 col-md-offset-2 col-sm-offset-0 col-xs-offset-0">
                <div class="sup_testimonial_heading">
                    <h3>What Our Client Say</h3>
                </div>
            </div>
            <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 col-lg-offset-2 col-md-offset-2 col-sm-offset-0 col-xs-offset-0">
                <div class="sup_testimonial_detail">
                    <p>Bras urna felis accumsan at ultrde cesid posuere masacis nautoque penat bus maecenas ultrices sed ipsum lorem dolor.</p>
                    <span>Jhon Doe</span>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\ThemePixel\resources\views/frontend/partials/client.blade.php ENDPATH**/ ?>