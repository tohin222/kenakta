<?php $__env->startSection('contains'); ?>
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Basic mSells
    </h1>
  </section>

  <!-- Main content -->
  <section class="content">

    <!-- SELECT2 EXAMPLE -->
    <div class="box box-default">

      <!-- /.box-header -->
      <div class="box-body">
        <div class="row">
          <div class="col-md-6 col-12">
            <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
          <?php endif; ?>
            <form action="<?php echo e(route('team.store')); ?>" method="post" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
                  <div class="form-group">
                    <label for="inputEmail4">Name</label>
                    <input type="text" class="form-control" name="name">
                  </div>
                  <div class="form-group">
                    <label for="inputEmail4">Post</label>
                    <input type="text" class="form-control" name="post">
                  </div>
                  <div class="form-group">
                    <label for="inputEmail4">Image Size : 280 X 420</label>
                    <input type="file" class="form-control" name="image">
                  </div>
              
                <button type="submit" class="btn btn-primary">Add</button>
              </form>
          </div>
        </div>
        <!-- /.row -->
      </div>
      <!-- /.box-body -->
    </div>
    <!-- /.box -->
    

  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ThemePixel\resources\views/backend/team/create.blade.php ENDPATH**/ ?>