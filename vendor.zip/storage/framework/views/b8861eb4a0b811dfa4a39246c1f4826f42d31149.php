

<!-- Bootstrap v4.1.3.stable -->
<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">

<!-- Font Awesome -->
<link rel="stylesheet" href="<?php echo e(asset('css/fontawesome/font-awesome.css')); ?>">

<!-- Theme style -->
<link rel="stylesheet" href="<?php echo e(asset('css/master_style.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('css/_all-skins.css')); ?>">	

<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">

<!-- bootstrap datepicker -->	
<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-datepicker.min.css')); ?>">	
<!-- Select2 -->
<link rel="stylesheet" href="<?php echo e(asset('css/select2.min.css')); ?>">

<!-- fullCalendar -->
<link rel="stylesheet" href="<?php echo e(asset('css/fullcalendar.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/fullcalendar.print.min.css')); ?>" media="print"><?php /**PATH C:\xampp\htdocs\ThemePixel\resources\views/backend/partials/css.blade.php ENDPATH**/ ?>