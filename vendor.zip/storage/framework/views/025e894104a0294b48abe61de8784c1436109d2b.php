<div id="portfolio" class="sup_transparent sup_toppadder100">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-10 col-sm-12 col-xs-12 col-lg-offset-2 col-md-offset-1 col-sm-offset-0 col-xs-offset-0">
                <div class="sup_heading text-center sup_bottompadder70">
                    <h4>Our Portfolio</h4>
                    <div class="sup_title_border"></div>
                    <p>Welcome to Theme pixel BD., one of the best software companies in Bangladesh.</p>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="sup_sorting sup_bottompadder30">
                    <ul id="portfolio-filter">
                        <li class="filters-line"></li>
                        <li><a href="#" class="filter active" data-filter="all">all</a>
                        </li>
                        <li><a href="#" class="filter" data-filter=".webdesign">web design </a>
                        </li>
                        <li><a href="#" class="filter" data-filter=".application"> Web application </a>
                        </li>
                        <li><a href="#" class="filter" data-filter=".illustration">Graphics</a>
                        </li>
                        <li><a href="#" class="filter" data-filter=".android">Android</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div >
                <?php $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $portfolio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 mix <?php echo e($portfolio->classname); ?>">
                    <div class="row">
                        <div class="portfolio-item frombottom wow" data-wow-duration="0.5s">
                            <div class="portfolio-image">
                                <img src="<?php echo e(asset('/storage')); ?>/<?php echo e($portfolio->image); ?>" class="img-responsive" alt="">
                                <div class="portfolio-overlay"></div>
                                <div class="sup_links">
                                    <a class="fancybox sup_link" data-fancybox-group="gallery1" href="<?php echo e(asset('/storage')); ?>/<?php echo e($portfolio->image); ?>" title="<?php echo e($portfolio->name); ?>"><i class="fa fa-search" aria-hidden="true"></i></a>
                                    <a href="<?php echo e($portfolio->link); ?>" class="sup_link" target="_blank"><i class="fa fa-link" aria-hidden="true"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
        
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\ThemePixel\resources\views/frontend/main/portfolio.blade.php ENDPATH**/ ?>