<div class="sup_welcome_section_wrapper">
    <div class="sup_blue_overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="sup_whoweare_section sup_toppadder100 sup_bottompadder100 sup_fullwidth_inner">
                    <h4>Welcome to Theme Pixel</h4>
                    <div class="sup_title_border"></div>
                    <div class="clearfix"></div>
                    <span>Theme Pixel has highly skilled engineers with excellent technical knowledge and experience in using the latest software standards, tools, platforms, frameworks, and technologies. We want you to be completely satisfied with our services. We will do whatever it takes to make you happy. </span>
                    
                    
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\ThemePixel\resources\views/frontend/partials/banner.blade.php ENDPATH**/ ?>