<?php $__env->startSection('contains'); ?>
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Basic mSells
    </h1>
  </section>

  <!-- Main content -->
  <section class="content">

    <!-- SELECT2 EXAMPLE -->
    <div class="box box-default">

      <!-- /.box-header -->
      <div class="box-body">
        <div class="row">
          <div class="col-md-12 col-12">
            <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
          <?php endif; ?>
                <table class="table table-hover table-responsive">
                  <thead>
                    <tr>
                      <th scope="col">Action</th>
                      <th scope="col">Facebook</th>
                      <th scope="col">Linkdin</th>
                      <th scope="col">twitter</th>
                      <th scope="col">Linkdin</th>
                      <th scope="col">pinterest</th>
                      <th scope="col">google</th>
                      <th scope="col">number</th>
                      <th scope="col">Image</th>
                     
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td>
                        <a class="btn btn-warning" href="<?php echo e(route('header.edit', $header->id)); ?>">edit</a>
                        <br><br>
                        <form action="<?php echo e(url('header', [$header->id])); ?>" method="POST">
                          <?php echo e(method_field('DELETE')); ?>

                          <?php echo csrf_field(); ?>
                          <input type="submit" class="btn btn-danger" value="Delete"/>
                       </form>
                        </td>
                    <td><?php echo e($header->facebook); ?></td>
                      <td><?php echo e($header->linkdin); ?></td>
                      <td><?php echo e($header->twitter); ?></td>
                      <td><?php echo e($header->pinterest); ?></td>
                      <td><?php echo e($header->google); ?></td>
                      <td><?php echo e($header->number); ?></td>
                      <td> 
                      <img src="<?php echo e(asset('/storage')); ?>/<?php echo e($header->image); ?>" alt="" height="80" width="140">
                      </td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                   
                  </tbody>
                </table>
          </div>
        </div>
        <!-- /.row -->
      </div>
      <!-- /.box-body -->
    </div>
    <!-- /.box -->
    

  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ThemePixel\resources\views/backend/header/index.blade.php ENDPATH**/ ?>