<?php $__env->startSection('contains'); ?>
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Basic mSells
    </h1>
  </section>

  <!-- Main content -->
  <section class="content">

    <!-- SELECT2 EXAMPLE -->
    <div class="box box-default">

      <!-- /.box-header -->
      <div class="box-body">
        <div class="row">
          <div class="col-md-6 col-12">
            <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
          <?php endif; ?>
            <form action="<?php echo e(route('client.update',$client->id)); ?>" method="post" enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                  <div class="form-group">
                    <label for="inputEmail4">Client Name</label>
                  <input type="hidden" class="form-control" name="id" value="<?php echo e($client->id); ?>">
                    <input type="text" class="form-control" name="name" value="<?php echo e($client->name); ?>">
                  </div>
                  <div class="form-group">
                    <label for="inputEmail4">Comment</label>
                    <input type="text" class="form-control" name="comment" value="<?php echo e($client->comment); ?>">
                  </div>
                  
                <button type="submit" class="btn btn-primary">Add</button>
              </form>
          </div>
        </div>
        <!-- /.row -->
      </div>
      <!-- /.box-body -->
    </div>
    <!-- /.box -->
    

  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ThemePixel\resources\views/backend/client/edit.blade.php ENDPATH**/ ?>