<div class="sup_slider_second">
    <div id="owl-demo" class="owl-carousel owl-theme">
       <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <div class="item">
        <div class="sup_bannerdata">
            <img src="<?php echo e(asset('/storage')); ?>/<?php echo e($banner->image); ?>" alt="">
            <div class="sup_banner">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="sup_banner_content">
                                <h1><?php echo e($banner->title); ?></h1>
                                <p><?php echo e($banner->content); ?> </p>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div><?php /**PATH C:\xampp\htdocs\ThemePixel\resources\views/frontend/partials/slider.blade.php ENDPATH**/ ?>