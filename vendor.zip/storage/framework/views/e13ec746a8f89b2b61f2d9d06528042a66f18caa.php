<aside class="main-sidebar">
    <!-- sidebar -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="image float-left">
          <img src="<?php echo e(asset('/images/user.png')); ?>" class="rounded" alt="User Image">
        </div>
        <div class="info float-left">
          <p>  <?php echo e(Auth::user()->name); ?></p>
          <a href="#"><i class="fa fa-circle text-success"></i>
            <?php
                if(Auth::user()->role===1){
              echo "Admin";
              }
              else {
              echo "SalesMan";
              }
            ?>
          </a>
        </div>
      </div>
      
      <!-- sidebar menu  -->
      <ul class="sidebar-menu" data-widget="tree">
        <li>
          <a href="<?php echo e(route('home')); ?>">
            <i class="fa fa-calendar"></i> <span>Basic mSells</span>
          </a>
        </li>
        <li>
          <a href="#">
            <i class="fa fa-calendar"></i> <span>Save List</span>
          </a>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-files-o"></i>
            <span>Product</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="#"><i class="fa fa-circle-o"></i> Product Add</a></li>
            <li><a href="#"><i class="fa fa-circle-o"></i> Product List</a></li>
          </ul>
        </li>
        <li>
          <a href="#">
            <i class="fa fa-calendar"></i> <span>Save List</span>
          </a>
        </li>
      </ul>
    </section>
    <!-- /.sidebar -->
 <!--   <div class="sidebar-footer">-->
		<!-- item-->
	<!--	<a href="#" class="link" data-toggle="tooltip" title="" data-original-title="Settings"><i class="fa fa-cog fa-spin"></i></a>-->
		<!-- item-->
	<!--	<a href="#" class="link" data-toggle="tooltip" title="" data-original-title="Email"><i class="fa fa-envelope"></i></a>-->
		<!-- item-->
	<!--	<a href="#" class="link" data-toggle="tooltip" title="" data-original-title="Logout"><i class="fa fa-power-off"></i></a>-->
	<!--</div>-->
  </aside><?php /**PATH C:\xampp\htdocs\readylaraveladmin\resources\views/backend/partials/aside.blade.php ENDPATH**/ ?>