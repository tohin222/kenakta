<div class="sup_transparent sup_toppadder100">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-10 col-sm-12 col-xs-12 col-lg-offset-2 col-md-offset-1 col-sm-offset-0 col-xs-offset-0">
                <div class="sup_heading text-center sup_bottompadder70">
                    <h4>Our Portfolio</h4>
                    <div class="sup_title_border"></div>
                    <p>Bras urna felis accumsan at ultrde cesid posuere masa socis nautoque penat bus maecenas ultrices sed ipsum lorem dolor sit amet sed ipsum consectetur adipisicing elit sed do eiusmod tempor incididunt</p>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="sup_sorting sup_bottompadder30">
                    <ul id="portfolio-filter">
                        <li class="filters-line"></li>
                        <li><a href="#" class="filter active" data-filter="all">all</a>
                        </li>
                        <li><a href="#" class="filter" data-filter=".webdesign">web design </a>
                        </li>
                        <li><a href="#" class="filter" data-filter=".illustration">illustration</a>
                        </li>
                        <li><a href="#" class="filter" data-filter=".print"> print </a>
                        </li>
                        <li><a href="#" class="filter" data-filter=".photography">photography</a>
                        </li>
                        <li><a href="#" class="filter" data-filter=".bni">branding & identity </a>
                        </li>
                    </ul>
                </div>
            </div>
            <div id="portfolio">
                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 mix mix-all webdesign photography" data-value="1">
                    <div class="row">
                        <div class="portfolio-item frombottom wow" data-wow-duration="0.5s">
                            <div class="portfolio-image">
                                <img src="<?php echo e(asset('frontend/images/portfolio_small7.jpg')); ?>" class="img-responsive" alt="">
                                <div class="portfolio-overlay"></div>
                                <div class="sup_links">
                                    <a class="fancybox sup_link" data-fancybox-group="gallery1" href="<?php echo e(asset('frontend/images/portfolio_big7.jpg')); ?>" title="Portfolio 7"><i class="fa fa-search" aria-hidden="true"></i></a>
                                    <a href="portfolio-single.html" class="sup_link"><i class="fa fa-link" aria-hidden="true"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 mix illustration bni" data-value="2">
                    <div class="row">
                        <div class="portfolio-item frombottom wow" data-wow-duration="0.6s">
                            <div class="portfolio-image">
                                <img src="<?php echo e(asset('frontend/images/portfolio_small8.jpg')); ?>" class="img-responsive" alt="">
                                <div class="portfolio-overlay"></div>
                                <div class="sup_links">
                                    <a class="fancybox sup_link" data-fancybox-group="gallery1" href="<?php echo e(asset('frontend/images/portfolio_big8.jpg')); ?>" title="Portfolio 8"><i class="fa fa-search" aria-hidden="true"></i></a>
                                    <a href="portfolio-single.html" class="sup_link"><i class="fa fa-link" aria-hidden="true"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 mix print" data-value="3">
                    <div class="row">
                        <div class="portfolio-item frombottom wow" data-wow-duration="0.7s">
                            <div class="portfolio-image">
                                <img src="<?php echo e(asset('frontend/images/portfolio_small9.jpg')); ?>" class="img-responsive" alt="">
                                <div class="portfolio-overlay"></div>
                                <div class="sup_links">
                                    <a class="fancybox sup_link" data-fancybox-group="gallery1" href="<?php echo e(asset('frontend/images/portfolio_big9.jpg')); ?>" title="Portfolio 9"><i class="fa fa-search" aria-hidden="true"></i></a>
                                    <a href="portfolio-single.html" class="sup_link"><i class="fa fa-link" aria-hidden="true"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 mix photography bni" data-value="4">
                    <div class="row">
                        <div class="portfolio-item frombottom wow" data-wow-duration="0.8s">
                            <div class="portfolio-image">
                                <img src="<?php echo e(asset('frontend/images/portfolio_small10.jpg')); ?>" class="img-responsive" alt="">
                                <div class="portfolio-overlay"></div>
                                <div class="sup_links">
                                    <a class="fancybox sup_link" data-fancybox-group="gallery1" href="<?php echo e(asset('frontend/images/portfolio_big10.jpg')); ?>" title="Portfolio 10"><i class="fa fa-search" aria-hidden="true"></i></a>
                                    <a href="portfolio-single.html" class="sup_link"><i class="fa fa-link" aria-hidden="true"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 mix illustration webdesign bni" data-value="5">
                    <div class="row">
                        <div class="portfolio-item frombottom wow" data-wow-duration="0.9s">
                            <div class="portfolio-image">
                                <img src="<?php echo e(asset('frontend/images/portfolio_small11.jpg')); ?>" class="img-responsive" alt="">
                                <div class="portfolio-overlay"></div>
                                <div class="sup_links">
                                    <a class="fancybox sup_link" data-fancybox-group="gallery1" href="<?php echo e(asset('frontend/images/portfolio_big11.jpg')); ?>" title="Portfolio 11"><i class="fa fa-search" aria-hidden="true"></i></a>
                                    <a href="portfolio-single.html" class="sup_link"><i class="fa fa-link" aria-hidden="true"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 mix print webdesign" data-value="6">
                    <div class="row">
                        <div class="portfolio-item frombottom wow" data-wow-duration="1s">
                            <div class="portfolio-image">
                                <img src="<?php echo e(asset('frontend/images/portfolio_small12.jpg')); ?>" class="img-responsive" alt="">
                                <div class="portfolio-overlay"></div>
                                <div class="sup_links">
                                    <a class="fancybox sup_link" data-fancybox-group="gallery1" href="<?php echo e(asset('frontend/images/portfolio_big12.jpg')); ?>" title="Portfolio 12"><i class="fa fa-search" aria-hidden="true"></i></a>
                                    <a href="portfolio-single.html" class="sup_link"><i class="fa fa-link" aria-hidden="true"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\ThemePixel\resources\views/frontend/partials/portfolio.blade.php ENDPATH**/ ?>