<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Theme Pixel</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="">
    <meta name="MobileOptimized" content="320">

    <?php echo $__env->make('frontend.partials.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <div class="sup_topborder"></div>
    <?php echo $__env->make('frontend.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('frontend.partials.navbar2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="sup_breadcrumb_section">
        <div class="sup_overlay"></div>
        <div class="sup_blue_overlay"></div>
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <div class="sup_pagetitle sup_toppadder90 sup_bottompadder90">
                        <h2>Contact us</h2>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <div class="sup_breadcrumb_div sup_toppadder90 sup_bottompadder90">
                        <ol class="breadcrumb">
                            <li><a href="index.html">Home</a>
                            </li>
                            <li class="active">Contact us</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="sup_transparent sup_toppadder100 sup_bottompadder100">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-10 col-sm-12 col-xs-12 col-lg-offset-2 col-md-offset-1 col-sm-offset-0 col-xs-offset-0">
                    <div class="sup_heading text-center sup_bottompadder70">
                        <h4>GET In touch</h4>
                        <div class="sup_title_border"></div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                    <div class="sup_service sup_contact zoom_middle wow" data-wow-duration="0.5s">
                        <span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="32px" height="32px" viewBox="0 0 32 32" enable-background="new 0 0 32 32" xml:space="preserve">
						<path fill-rule="evenodd" clip-rule="evenodd" fill="#31AAE1" d="M16,16V0h1c7.71,0,15,7.29,15,15v1H16z M18,1.551V14h11.953
							C29.397,8.033,23.967,2.107,18,1.551z M14.004,30c6.617,0,12-5.384,12-12h2c0,7.72-6.28,14-14,14S0,26.216,0,18.495
							C0,10.776,6.28,4.497,14,4.497v1.999c-6.617,0-12,5.383-12,12C2,25.112,7.387,30,14.004,30z"/>
						</svg></span>
                        <h5>Phone</h5>
                        <div class="sup_title_border"></div>
                        <p>Phone : +8801684011278
                            <br> Phone : +8801751473951
                        </p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                    <div class="sup_service sup_contact zoom_middle wow" data-wow-duration="0.7s">
                        <span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="32px" height="32px" viewBox="0 0 32 32" enable-background="new 0 0 32 32" xml:space="preserve">
						<g>
							<g>
								<path fill="#31AAE1" d="M0,18.951c0,3.421,2.579,6,6,6h1v-12H6C2.579,12.951,0,15.53,0,18.951z M4.999,22.842
									C3.213,22.43,2,20.92,2,18.951c0-1.968,1.214-3.479,2.999-3.889V22.842z M25.998,12.951H25v12h0.998c3.422,0,6.002-2.579,6.002-6
									C32,15.53,29.42,12.951,25.998,12.951z M27,22.842v-7.78c1.785,0.41,3,1.921,3,3.889C30,20.92,28.785,22.43,27,22.842z M27,27.951
									h-4v2h4c1.709,0,3-1.29,3-3h-2.002C27.998,27.641,27.496,27.951,27,27.951z M19.938,25.96c-1.654,0-3,1.346-3,2.999
									c0,1.656,1.345,3,3,3s3-1.344,3-3C22.938,27.306,21.592,25.96,19.938,25.96z M19.938,29.961c-0.553,0-1-0.449-1-1.002
									c0-0.551,0.447-0.998,1-0.998c0.551,0,1,0.447,1,0.998C20.938,29.512,20.488,29.961,19.938,29.961z M25,10.957h2
									C27,4.89,22.064-0.049,16-0.049c-6.065,0-11.001,4.938-11.001,11.006H7c0-4.967,4.037-9.005,9-9.005
									C20.961,1.952,25,5.99,25,10.957z"/>
							</g>
						</g>
						</svg></span>
                        <h5>address</h5>
                        <div class="sup_title_border"></div>
                        <p>Cloud base (Remote area)

                            
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                    <div class="sup_service sup_contact zoom_middle wow" data-wow-duration="0.6s">
                        <span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="30.219px" height="26.251px" viewBox="0 0 30.219 26.251" enable-background="new 0 0 30.219 26.251" xml:space="preserve">
						<path fill-rule="evenodd" clip-rule="evenodd" fill="#31AAE1" d="M15.109,16.271L0,8.136L15.109,0l15.109,8.136L15.109,16.271z
							 M4.219,8.136L15.109,14L26,8.136L15.109,2.271L4.219,8.136z M15.109,18.894l13.56-6.655l0.881,1.795l-14.44,7.087l-14.44-7.087
							l0.881-1.795L15.109,18.894z M15.109,24.022l13.56-6.654l0.881,1.795l-14.44,7.088l-14.44-7.088l0.881-1.795L15.109,24.022z"/>
						</svg></span>
                        <h5>email</h5>
                        <div class="sup_title_border"></div>
                        <p><a href="javascript:;">themepixel230@gmail.com
                        </a> <a href="javascript:;">Support@themepixel230.com</a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="sup_map_section">
        <div class="sup_blue_overlay"></div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="sup_contact_form fromright wow" data-wow-duration="0.5s">
                            <div class="sup_heading">
                                <h4>send a message</h4>
                                <div class="sup_title_border"></div>
                            </div>
                            <div class="sup_contact">
                                <div class="row">
                                <form action="<?php echo e(route('mycontact.store')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                        <div class="form-group">
                                            <input type="text" class="form-control" id="ur_name" placeholder="Name" name="name">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                        <div class="form-group">
                                            <input type="text" class="form-control" id="ur_mail" placeholder="Email" name="email">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                        <div class="form-group">
                                            <input type="text" class="form-control" id="ur_phone" placeholder="Phone" name="phone">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                        <div class="form-group">
                                            <input type="text" class="form-control" id="sub" placeholder="Subject" name="subject">
                                        </div>
                                    </div>
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                        <div class="form-group">
                                            <textarea rows="7" class="form-control" id="msg" placeholder="Message" name="message"></textarea>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                        <div class="form-group">
                                            <button class="sup_btn sup_black_btn" id="send_btn">submit <span><i class="fa fa-angle-right" aria-hidden="true"></i></span>
                                            </button>
                                            <p id="err"></p>
                                        </div>
                                    </div>
                                </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    
                </div>
            </div>
        </div>
    <?php echo $__env->make('frontend.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('frontend.partials.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH C:\xampp\htdocs\ThemePixel\resources\views/frontend/contact.blade.php ENDPATH**/ ?>