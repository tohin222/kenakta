<div class="sup_transparent sup_toppadder100 sup_bottompadder30">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-10 col-sm-12 col-xs-12 col-lg-offset-2 col-md-offset-1 col-sm-offset-0 col-xs-offset-0">
                <div class="sup_heading text-center sup_bottompadder70">
                    <h4>Our Features</h4>
                    <div class="sup_title_border"></div>
                    <p>Bras urna felis accumsan at ultrde cesid posuere masa socis nautoque penat bus maecenas ultrices sed ipsum lorem dolor sit amet sed ipsum consectetur adipisicing elit sed do eiusmod tempor incididunt</p>
                </div>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="sup_feature_type2">
                    <ul class="nav nav-tabs" role="tablist">
                        <li role="presentation" class="active">
                            <a href="#wg" aria-controls="wg" role="tab" data-toggle="tab" aria-expanded="true">
                                <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="44px" height="50.994px" viewBox="0 0 44 50.994" enable-background="new 0 0 44 50.994" xml:space="preserve">
                                    <path fill-rule="evenodd" clip-rule="evenodd" fill="#31AAE1" d="M36.648,36.839c-4.902,4.926-11.342,7.39-17.781,7.39
                        c-6.438,0-12.877-2.464-17.777-7.39l2.222-2.232c8.579,8.621,22.536,8.618,31.114,0c8.577-8.626,8.577-22.657,0-31.278l2.223-2.233
                        C46.45,10.947,46.45,26.981,36.648,36.839z M18.857,37.912C8.459,37.912,0,29.409,0,18.957C0,8.502,8.459,0,18.857,0
                        c10.397,0,18.857,8.502,18.857,18.957C37.715,29.409,29.255,37.912,18.857,37.912z M18.857,3.159
                        c-8.666,0-15.715,7.088-15.715,15.798c0,8.709,7.049,15.796,15.715,15.796c8.665,0,15.715-7.087,15.715-15.796
                        C34.572,10.247,27.522,3.159,18.857,3.159z M29.139,23.54l-9.582,9.186l1.595-11.206l-6.765-3.736l3.899-5.285l-0.624-0.243
                        l-5.479,1.381L8.675,10.69l2.017-2.425l2.278,1.916l4.897-1.235l5.397,2.108l-4.208,5.707l5.514,3.045l-0.617,4.339l2.354-2.254
                        l2.024-8.279l3.052,0.752L29.139,23.54z M13.716,26.997h-3.094l0.593-3H8v-2.999h6.874L13.716,26.997z M27,50.994H11v-2.999h16
                        V50.994z" />
                                </svg> <span>WORK GLOBAL</span>
                            </a>
                        </li>
                        <li role="presentation" class="">
                            <a href="#mf" aria-controls="mf" role="tab" data-toggle="tab" aria-expanded="false">
                                <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="44px" height="38px" viewBox="0 0 44 38" enable-background="new 0 0 44 38" xml:space="preserve">
                                    <g>
                                        <g>
                                            <path fill="#31AAE1" d="M0,38.008h44v-2.702H0V38.008z M11.036,23.498L22.011,5.267l11.187,18.268l2.355-1.394L21.989-0.008
                                    L8.67,22.121L11.036,23.498z M32.31,12.342l1.611,2.19l7.329-5.206v20.575H2.75V9.326l7.329,5.206l1.611-2.19L0,4.038v29.117h44
                                    V4.038L32.31,12.342z" />
                                        </g>
                                    </g>
                                </svg> <span>MAIN FEATURES</span>
                            </a>
                        </li>
                        <li role="presentation" class="">
                            <a href="#pl" aria-controls="pl" role="tab" data-toggle="tab" aria-expanded="false">
                                <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="46px" height="46.495px" viewBox="0 0 46 46.495" enable-background="new 0 0 46 46.495" xml:space="preserve">
                                    <path fill-rule="evenodd" clip-rule="evenodd" fill="#31AAE1" d="M33.789,24.717l-2.156-2.052L43,11.197V3h-8.142L23.616,14.47
                            l-2.034-2.149L33.789,0H46v12.398L33.789,24.717z M16.409,28.088l6.967-7.267l2.068,2.019l-7,7.3l6.429,6.486l3.728-10.578
                            l2.712,0.973L26.059,41.93L4.523,20.201L19.3,14.899l0.964,2.736L9.779,21.397L16.409,28.088z M9.924,31.127l-4.253,9.646
                            l9.562-4.291l1.169,2.654L0,46.496l7.293-16.549L9.924,31.127z" />
                                </svg> <span>PROJECTS LAUNCH</span>
                            </a>
                        </li>
                        <li role="presentation" class="">
                            <a href="#aw" aria-controls="aw" role="tab" data-toggle="tab" aria-expanded="false">
                                <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="45px" height="44.917px" viewBox="0 0 45 44.917" enable-background="new 0 0 45 44.917" xml:space="preserve">
                                    <path fill-rule="evenodd" clip-rule="evenodd" fill="#31AAE1" d="M38,12.849v-2.75c2.294,0,4-0.849,4-3.125V7h-4v-3h7v3.224
                        C45,11.014,41.823,12.849,38,12.849z M11,41.996h11v-7.694c-2.387-0.614-4.161-2.749-4.161-5.304h2.387
                        c0,1.516,1.244,3.773,2.774,3.773c1.529,0,2.773-2.258,2.773-3.773h2.388c0,2.555-1.775,4.689-4.161,5.304v7.694h11v3H11V41.996z
                         M22,25.222c-6.884,0-12-5.551-12-12.374V0h25v12.849C35,19.671,28.883,25.222,22,25.222z M32,2.999H13v9.85
                        c0,5.307,3.646,9.625,9,9.625c5.354,0,10-4.318,10-9.625V2.999z M16,12.973V7h3v5.974c0,2.274,1.705,4,4,4v2.75
                        C19.176,19.723,16,16.764,16,12.973z M0.736,6.474L0,3.999h8v3H4v0.476c0,2.273,1.705,2.624,4,2.624v2.75
                        C4.176,12.849,0.736,10.265,0.736,6.474z" />
                                </svg><span>AWARDS WINNER</span>
                            </a>
                        </li>
                    </ul>

                    <!-- Tab panes -->
                    <div class="tab-content">
                        <div role="tabpanel" class="tab-pane active" id="wg">
                            <div class="sup_tabdata">
                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                        <div class="sup_feature_img fromleft wow">
                                            <img src="<?php echo e(asset('frontend/images/feature1.png')); ?>" class="img-responsive" alt="">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                        <div class="sup_feature_detail">
                                            <h3>We Offer Unique Services</h3>
                                            <span>That Are Based On Unique Ideas..</span>
                                            <div class="sup_title_border"></div>
                                            <h5>Quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commod</h5>
                                            <p>Fusce ultrices hendrerit. Donec libero pede porttitor accumsan venenatis quis velit. Viam ligula mauris blandit pulvinar porta enim. Integer varius erat sapien. Nunc massa urnader imperdiet necdel suc piter in semper nec sem fusce. Lorem ipsum dolor sit amet.</p>
                                            <a href="service.html">Learn More</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div role="tabpanel" class="tab-pane" id="mf">
                            <div class="sup_tabdata">
                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 col-lg-push-6 col-md-push-6 col-sm-push-0 col-xs-push-0">
                                        <div class="sup_feature_img fromright wow">
                                            <img src="<?php echo e(asset('frontend/images/feature2.png')); ?>" class="img-responsive" alt="">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 col-lg-pull-6 col-md-pull-6 col-sm-pull-0 col-xs-pull-0">
                                        <div class="sup_feature_detail">
                                            <h3>We Offer Unique Services</h3>
                                            <span>That Are Based On Unique Ideas..</span>
                                            <div class="sup_title_border"></div>
                                            <h5>Quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commod</h5>
                                            <p>Fusce ultrices hendrerit. Donec libero pede porttitor accumsan venenatis quis velit. Viam ligula mauris blandit pulvinar porta enim. Integer varius erat sapien. Nunc massa urnader imperdiet necdel suc piter in semper nec sem fusce. Lorem ipsum dolor sit amet.</p>
                                            <a href="service.html">Learn More</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div role="tabpanel" class="tab-pane" id="pl">
                            <div class="sup_tabdata">
                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                        <div class="sup_feature_img fromleft wow">
                                            <img src="<?php echo e(asset('frontend/images/feature1.png')); ?>" class="img-responsive" alt="">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                        <div class="sup_feature_detail">
                                            <h3>We Offer Unique Services</h3>
                                            <span>That Are Based On Unique Ideas..</span>
                                            <div class="sup_title_border"></div>
                                            <h5>Quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commod</h5>
                                            <p>Fusce ultrices hendrerit. Donec libero pede porttitor accumsan venenatis quis velit. Viam ligula mauris blandit pulvinar porta enim. Integer varius erat sapien. Nunc massa urnader imperdiet necdel suc piter in semper nec sem fusce. Lorem ipsum dolor sit amet.</p>
                                            <a href="service.html">Learn More</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div role="tabpanel" class="tab-pane" id="aw">
                            <div class="sup_tabdata">
                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 col-lg-push-6 col-md-push-6 col-sm-push-0 col-xs-push-0">
                                        <div class="sup_feature_img fromright wow">
                                            <img src="<?php echo e(asset('frontend/images/feature2.png')); ?>" class="img-responsive" alt="">
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 col-lg-pull-6 col-md-pull-6 col-sm-pull-0 col-xs-pull-0">
                                        <div class="sup_feature_detail">
                                            <h3>We Offer Unique Services</h3>
                                            <span>That Are Based On Unique Ideas..</span>
                                            <div class="sup_title_border"></div>
                                            <h5>Quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commod</h5>
                                            <p>Fusce ultrices hendrerit. Donec libero pede porttitor accumsan venenatis quis velit. Viam ligula mauris blandit pulvinar porta enim. Integer varius erat sapien. Nunc massa urnader imperdiet necdel suc piter in semper nec sem fusce. Lorem ipsum dolor sit amet.</p>
                                            <a href="service.html">Learn More</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\ThemePixel\resources\views/frontend/partials/feature.blade.php ENDPATH**/ ?>