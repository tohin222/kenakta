<footer class="main-footer">
  <div class="pull-right d-none d-sm-inline-block">
      <b>Version</b> 1.0
  </div>Copyright &copy; 2019 <a href="https://www.Themepxele.com/">ThemePixel-Purpose Themes</a>. Pampered by ThemePixel.
</footer><?php /**PATH C:\xampp\htdocs\ThemePixel\resources\views/backend/partials/footer.blade.php ENDPATH**/ ?>