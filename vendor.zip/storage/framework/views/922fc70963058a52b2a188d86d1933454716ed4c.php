<?php $__env->startSection('contains'); ?>
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Basic mSells
    </h1>
  </section>

  <!-- Main content -->
  <section class="content">

    <!-- SELECT2 EXAMPLE -->
    <div class="box box-default">

      <!-- /.box-header -->
      <div class="box-body">
        <div class="row">
          <div class="col-md-12 col-12">
            <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
          <?php endif; ?>
                <table class="table table-hover">
                  <thead>
                    <tr>
                      <th scope="col">#</th>
                      <th scope="col">Name</th>
                      <th scope="col">Email</th>
                      <th scope="col">Phone</th>
                      <th scope="col">Subject</th>
                      <th scope="col">Message</th>
                      <th scope="col">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__currentLoopData = $mycontacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mycontact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <th scope="row">1</th>
                    <td><?php echo e($mycontact->name); ?></td>
                      <td><?php echo e($mycontact->email); ?></td>
                      <td><?php echo e($mycontact->phone); ?></td>
                      <td><?php echo e($mycontact->subject); ?></td>
                      <td><?php echo e($mycontact->message); ?></td>
                      <td>
                        <a class="btn btn-danger" href="<?php echo e(route('contact.delete', $mycontact->id)); ?>">Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                   
                  </tbody>
                </table>
          </div>
        </div>
        <!-- /.row -->
      </div>
      <!-- /.box-body -->
    </div>
    <!-- /.box -->
    

  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ThemePixel\resources\views/backend/contact.blade.php ENDPATH**/ ?>