
    <div class="sup_transparent">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="row">
                        <div class="sup_service sup_service_type2">
                            <span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="32px" height="32px" viewBox="0 0 32 32" enable-background="new 0 0 32 32" xml:space="preserve">
						<path fill-rule="evenodd" clip-rule="evenodd" fill="#31AAE1" d="M16,16V0h1c7.71,0,15,7.29,15,15v1H16z M18,1.551V14h11.953
							C29.397,8.033,23.967,2.107,18,1.551z M14.004,30c6.617,0,12-5.384,12-12h2c0,7.72-6.28,14-14,14S0,26.216,0,18.495
							C0,10.776,6.28,4.497,14,4.497v1.999c-6.617,0-12,5.383-12,12C2,25.112,7.387,30,14.004,30z"/>
						</svg></span>
                            <h5>Analyze</h5>
                            <div class="sup_title_border"></div>
                            <p>Cras urna felis accumsan at ultricesid posuere.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="row">
                        <div class="sup_service sup_service_type2">
                            <span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="30.219px" height="26.251px" viewBox="0 0 30.219 26.251" enable-background="new 0 0 30.219 26.251" xml:space="preserve">
						<path fill-rule="evenodd" clip-rule="evenodd" fill="#31AAE1" d="M15.109,16.271L0,8.136L15.109,0l15.109,8.136L15.109,16.271z
							 M4.219,8.136L15.109,14L26,8.136L15.109,2.271L4.219,8.136z M15.109,18.894l13.56-6.655l0.881,1.795l-14.44,7.087l-14.44-7.087
							l0.881-1.795L15.109,18.894z M15.109,24.022l13.56-6.654l0.881,1.795l-14.44,7.088l-14.44-7.088l0.881-1.795L15.109,24.022z"/>
						</svg></span>
                            <h5>Design</h5>
                            <div class="sup_title_border"></div>
                            <p>Cras urna felis accumsan at ultricesid posuere.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="row">
                        <div class="sup_service sup_service_type2">
                            <span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="32px" height="23.735px" viewBox="0 0 32 23.735" enable-background="new 0 0 32 23.735" xml:space="preserve">
						<path fill-rule="evenodd" clip-rule="evenodd" fill="#31AAE1" d="M16.077,1.718c-0.053,0-0.105,0.016-0.159,0.016
							C8.679,1.794,2.563,5.796,1.994,10.846H0.005C0.699,4.708,7.533,0.027,15.902-0.042c0.057,0,0.115,0.015,0.173,0.015
							c8.15,0,15.123,4.751,15.917,10.872h-1.984C29.342,5.706,23.238,1.718,16.077,1.718z M16.067,19.845h-0.068
							c-4.374,0-7.962-3.558-7.998-7.932c-0.037-4.411,3.522-8.03,7.934-8.067c4.441,0,8.031,3.559,8.066,7.934
							c0.018,2.137-0.799,4.153-2.297,5.676S18.203,19.829,16.067,19.845z M22,11.796c-0.027-3.281-2.719-5.95-6-5.95
							c-3.358,0.028-6.026,2.741-5.999,6.049c0.027,3.281,2.718,5.95,5.998,5.95v1.001v-1.001c1.602-0.013,3.104-0.65,4.229-1.793
							C21.352,14.912,22.014,13.4,22,11.796z M14.016,11.846h-1.984c-0.019-2.206,1.762-3.981,3.968-4v1.983
							C14.897,9.839,14.007,10.743,14.016,11.846z M15.924,21.975c0.053,0,0.105-0.017,0.159-0.017c7.237-0.061,13.354-4.063,13.922-9.112
							h1.988c-0.693,6.138-7.525,10.819-15.895,10.889c-0.057,0-0.115-0.017-0.173-0.017c-8.151,0-15.126-4.75-15.919-10.872h1.984
							C2.657,17.986,8.761,21.975,15.924,21.975z"/>
						</svg></span>
                            <h5>Develop</h5>
                            <div class="sup_title_border"></div>
                            <p>Cras urna felis accumsan at ultricesid posuere.</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="row">
                        <div class="sup_service sup_service_type2">
                            <span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="32px" height="32px" viewBox="0 0 32 32" enable-background="new 0 0 32 32" xml:space="preserve">
						<g>
							<g>
								<path fill="#31AAE1" d="M0,18.951c0,3.421,2.579,6,6,6h1v-12H6C2.579,12.951,0,15.53,0,18.951z M4.999,22.842
									C3.213,22.43,2,20.92,2,18.951c0-1.968,1.214-3.479,2.999-3.889V22.842z M25.998,12.951H25v12h0.998c3.422,0,6.002-2.579,6.002-6
									C32,15.53,29.42,12.951,25.998,12.951z M27,22.842v-7.78c1.785,0.41,3,1.921,3,3.889C30,20.92,28.785,22.43,27,22.842z M27,27.951
									h-4v2h4c1.709,0,3-1.29,3-3h-2.002C27.998,27.641,27.496,27.951,27,27.951z M19.938,25.96c-1.654,0-3,1.346-3,2.999
									c0,1.656,1.345,3,3,3s3-1.344,3-3C22.938,27.306,21.592,25.96,19.938,25.96z M19.938,29.961c-0.553,0-1-0.449-1-1.002
									c0-0.551,0.447-0.998,1-0.998c0.551,0,1,0.447,1,0.998C20.938,29.512,20.488,29.961,19.938,29.961z M25,10.957h2
									C27,4.89,22.064-0.049,16-0.049c-6.065,0-11.001,4.938-11.001,11.006H7c0-4.967,4.037-9.005,9-9.005
									C20.961,1.952,25,5.99,25,10.957z"/>
							</g>
						</g>
						</svg></span>
                            <h5>Support</h5>
                            <div class="sup_title_border"></div>
                            <p>Cras urna felis accumsan at ultricesid posuere.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div><?php /**PATH C:\xampp\htdocs\ThemePixel\resources\views/frontend/partials/analyze.blade.php ENDPATH**/ ?>