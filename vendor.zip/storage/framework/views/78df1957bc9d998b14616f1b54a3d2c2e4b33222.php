<?php $__env->startSection('sections'); ?>
<div class="login-box">
    <div class="login-logo">
      <a href="../../index.html"><b>Theme</b>Pixel</a>
    </div>
    <!-- /.login-logo -->
    <div class="login-box-body">
      <p class="login-box-msg">Sign in to start your session</p>
  
      <form method="POST" action="<?php echo e(route('password.email')); ?>">
        <?php echo csrf_field(); ?>
         <div class="form-group">
           <input placeholder="Enter Email Address" id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required>
           <?php if($errors->has('email')): ?>
                               <span class="invalid-feedback" role="alert">
                                   <strong><?php echo e($errors->first('email')); ?></strong>
                               </span>
                           <?php endif; ?>
         </div>
        
           <div class="form-group">
           <button type="submit" class="btn btn-success w-100">
               <?php echo e(__('Send Password Reset Link')); ?>

                           </button>
         </div>
        
       </form>
  
    </div>
    <!-- /.login-box-body -->
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\readylaraveladmin\resources\views/auth/passwords/email.blade.php ENDPATH**/ ?>