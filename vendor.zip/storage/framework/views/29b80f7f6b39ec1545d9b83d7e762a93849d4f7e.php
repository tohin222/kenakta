<div class="sup_transparent sup_services_section3 sup_toppadder100">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 sup_bottompadder100">
                <div class="sup_service3_div zoom_middle wow" data-wow-duration="0.5s">
                    <div class="sup_service_icon">
                        <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="32px" height="26px" viewBox="0 0 32 26" enable-background="new 0 0 32 26" xml:space="preserve">
                            <g>
                                <path fill="none" d="M-569.5,280v22h13.075v-2H-567.5v-18.001h27.999V300h-11.016v2h13.016v-22H-569.5z M-541.5,284h-24v14h24V284z
                             M-543.5,295.999h-20v-10h20V295.999z M-552.5,299.926h-2V302h2V299.926z M-559.537,306h12.074v-2h-12.074V306z" />
                            </g>
                            <g>
                                <g>
                                    <path fill="#31AAE1" d="M0,0v22h13.075v-2H2V1.999h28V20H18.984v2H32V0H0z M28,4H4v14h24V4z M26,15.999H6v-10h20V15.999z
                                 M17,19.926h-2V22h2V19.926z M9.963,26h12.074v-2H9.963V26z" />
                                </g>
                            </g>
                        </svg>
                    </div>
                    <div class="sup_service_content">
                        <h4>Design To Brag About</h4>
                        <p>Phasellus enim libero, blandit vel sapien vitae, condimentum ultricies magna et. Quisque euismod orci ut et lobortis aliquam. </p>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 sup_bottompadder100">
                <div class="sup_service3_div zoom_middle wow" data-wow-duration="0.7s">
                    <div class="sup_service_icon">
                        <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="17.991px" height="26px" viewBox="0 0 17.991 26" enable-background="new 0 0 17.991 26" xml:space="preserve">
                            <path fill-rule="evenodd" clip-rule="evenodd" fill="#31AAE1" d="M0,25.996v-4.875h17.991v4.875H0z M16.355,22.746H1.636v1.625
                        h14.72V22.746z M6.542,6.496c0,1.345,1.101,2.438,2.453,2.438v1.624c-2.254,0-4.089-1.822-4.089-4.063H6.542z M8.996,17.06
                        c-1.353,0-2.453,1.092-2.453,2.437H4.907c0-2.239,1.834-4.063,4.089-4.063V17.06z M1.636,6.496h1.635
                        c0,3.137,2.568,5.689,5.725,5.689c3.157,0,5.725-2.553,5.725-5.689h1.635c0,2.832-1.629,5.287-4.004,6.5
                        c2.375,1.216,4.004,3.671,4.004,6.5h-1.635c0-3.135-2.568-5.687-5.725-5.687c-3.156,0-5.725,2.552-5.725,5.687H1.636
                        c0-2.829,1.63-5.284,4.003-6.5C3.266,11.783,1.636,9.328,1.636,6.496z M0-0.003h17.991v4.874H0V-0.003z M1.636,3.246h14.72V1.622
                        H1.636V3.246z" />
                        </svg>
                    </div>
                    <div class="sup_service_content">
                        <h4>Completely Customizable</h4>
                        <p>Phasellus enim libero, blandit vel sapien vitae, condimentum ultricies magna et. Quisque euismod orci ut et lobortis aliquam. </p>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 sup_bottompadder100">
                <div class="sup_service3_div zoom_middle wow" data-wow-duration="0.9s">
                    <div class="sup_service_icon">
                        <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="24.988px" height="28px" viewBox="0 0 24.988 28" enable-background="new 0 0 24.988 28" xml:space="preserve">
                            <path fill-rule="evenodd" clip-rule="evenodd" fill="#31AAE1" d="M0,16.621v-0.875C0,8.991,5.605,3.497,12.495,3.497
                            c6.889,0,12.493,5.494,12.493,12.249v0.875H0z M12.495,5.247c-5.604,0-10.218,4.243-10.673,9.626h21.345
                            C22.712,9.49,18.1,5.247,12.495,5.247z M12.495,6.996v1.751c-3.021,0-5.727,1.878-6.734,4.672l-1.684-0.583
                            C5.338,9.344,8.721,6.996,12.495,6.996z M11.603-0.003h1.784v1.749h-1.784V-0.003z M10.71,26.248c0.492,0,0.893-0.393,0.893-0.876
                            v-7h1.784v7c0,1.448-1.2,2.625-2.677,2.625c-1.476,0-2.677-1.177-2.677-2.625h1.784C9.817,25.855,10.218,26.248,10.71,26.248z" />
                        </svg>
                    </div>
                    <div class="sup_service_content">
                        <h4>SEO Optimized</h4>
                        <p>Phasellus enim libero, blandit vel sapien vitae, condimentum ultricies magna et. Quisque euismod orci ut et lobortis aliquam. </p>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 sup_bottompadder100">
                <div class="sup_service3_div zoom_middle wow" data-wow-duration="0.6s">
                    <div class="sup_service_icon">
                        <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="32px" height="32px" viewBox="0 0 32 32" enable-background="new 0 0 32 32" xml:space="preserve">
                            <path fill-rule="evenodd" clip-rule="evenodd" fill="#31AAE1" d="M16,15.999V0h1c7.709,0,15,7.29,15,15.001v0.998H16z M18,1.55
                        v12.449h11.953C29.397,8.033,23.967,2.106,18,1.55z M14.004,29.999c6.617,0,12-5.381,12-11.998h2c0,7.719-6.28,13.999-14,13.999
                        S0,26.216,0,18.497C0,10.776,6.28,4.496,14,4.496v2c-6.617,0-12,5.384-12,12.001C2,25.113,7.387,29.999,14.004,29.999z" />
                        </svg>
                    </div>
                    <div class="sup_service_content">
                        <h4>Clean Modern Code</h4>
                        <p>Phasellus enim libero, blandit vel sapien vitae, condimentum ultricies magna et. Quisque euismod orci ut et lobortis aliquam. </p>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 sup_bottompadder100">
                <div class="sup_service3_div zoom_middle wow" data-wow-duration="0.8s">
                    <div class="sup_service_icon">
                        <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="28px" height="32px" viewBox="0 0 28 32" enable-background="new 0 0 28 32" xml:space="preserve">
                            <g>
                                <g>
                                    <path fill="#31AAE1" d="M5,0H3v7.999h2V0z M3,32h2V20H3V32z M4,10c-2.206,0-4,1.793-4,4c0,2.206,1.794,3.999,4,3.999
                                S8,16.206,8,14C8,11.793,6.206,10,4,10z M4,16c-1.103,0-2-0.897-2-2c0-1.104,0.897-2,2-2s2,0.896,2,2C6,15.103,5.103,16,4,16z
                                 M15,0h-2v16h2V0z M13,32h2v-4.001h-2V32z M14,17.999c-2.206,0-4,1.794-4,4.001c0,2.205,1.794,4,4,4s4-1.795,4-4
                                C18,19.793,16.206,17.999,14,17.999z M14,24c-1.103,0-2-0.898-2-2c0-1.104,0.897-2,2-2s2,0.896,2,2C16,23.102,15.103,24,14,24z
                                 M25,0h-2v4h2V0z M23,32h2V16h-2V32z M24,5.999c-2.206,0-4,1.794-4,4.001c0,2.206,1.794,4,4,4s4-1.794,4-4
                                C28,7.793,26.206,5.999,24,5.999z M24,12c-1.103,0-2-0.898-2-2c0-1.104,0.897-2.001,2-2.001S26,8.896,26,10
                                C26,11.102,25.103,12,24,12z" />
                                </g>
                            </g>
                        </svg>
                    </div>
                    <div class="sup_service_content">
                        <h4>Free Updates & Support</h4>
                        <p>Phasellus enim libero, blandit vel sapien vitae, condimentum ultricies magna et. Quisque euismod orci ut et lobortis aliquam. </p>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 sup_bottompadder100">
                <div class="sup_service3_div zoom_middle wow" data-wow-duration="1s">
                    <div class="sup_service_icon">
                        <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="32px" height="22.268px" viewBox="0 0 32 22.268" enable-background="new 0 0 32 22.268" xml:space="preserve">
                            <g>
                                <g>
                                    <path fill="#31AAE1" d="M6.853,1.974L18,3.833v16.153H2V7.987h11.966V5.986H0v16h20V2.14L7.182,0L6.853,1.974z M13.966,11.986v-2
                                H4v2H13.966z M22.758,8.017l0.484,1.939L30,8.268v11.438l-6.758-1.689l-0.484,1.939L32,22.268V5.706L22.758,8.017z" />
                                </g>
                            </g>
                        </svg>
                    </div>
                    <div class="sup_service_content">
                        <h4>In-Depth Tutorial Videos</h4>
                        <p>Phasellus enim libero, blandit vel sapien vitae, condimentum ultricies magna et. Quisque euismod orci ut et lobortis aliquam. </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\ThemePixel\resources\views/frontend/partials/brag.blade.php ENDPATH**/ ?>