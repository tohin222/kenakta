<div class="sup_topheader sup_toppadder40 sup_bottompadder40">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                <div class="sup_phoneno">
                    <ul>
                        <?php $__currentLoopData = $headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="javascript:;"><span><i class="fa fa-phone" aria-hidden="true"></i></span><?php echo e($header->number); ?></a>
                            </li>
                            <?php break; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 text-center">
                <div class="sup_logo">
                    <a href="<?php echo e(route('banner')); ?>"><img src="<?php echo e(asset('frontend/images/logo.png')); ?>" class="img-responsive" alt="Theme-Pixel">
                    </a>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                <div class="sup_social_link">
                    <ul>
                        <?php $__currentLoopData = $headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e($header->facebook); ?>" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                                </li>
                                <li><a href="<?php echo e($header->twitter); ?>" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                                </li>
                                <li><a href="<?php echo e($header->pinterest); ?>" target="_blank"><i class="fa fa-pinterest-p" aria-hidden="true"></i></a>
                                </li>
                                <li><a href="<?php echo e($header->linkdin); ?>" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
                                </li>
                                <li><a href="<?php echo e($header->google); ?>" target="_blank"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
                                </li>
                            <?php break; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\ThemePixel\resources\views/frontend/partials/header.blade.php ENDPATH**/ ?>