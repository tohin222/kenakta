<aside class="main-sidebar">
    <!-- sidebar -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="image float-left">
          <img src="<?php echo e(asset('/images/user.png')); ?>" class="rounded" alt="User Image">
        </div>
        <div class="info float-left">
          <p>  <?php echo e(Auth::user()->name); ?></p>
          <a href="#"><i class="fa fa-circle text-success"></i>
            <?php
                if(Auth::user()->role===1){
              echo "Admin";
              }
              else {
              echo "SalesMan";
              }
            ?>
          </a>
        </div>
      </div>
      
      <!-- sidebar menu  -->
      <ul class="sidebar-menu" data-widget="tree">
        <li>
          <a href="<?php echo e(route('home')); ?>">
            <i class="fa fa-calendar"></i> <span>Basic mSells</span>
          </a>
        </li>
        <li>
        <a href="<?php echo e(route('profile')); ?>">
            <i class="fa fa-calendar"></i> <span>Profile</span>
          </a>
        </li>
        <li>
          <a href="<?php echo e(route('backend_contact')); ?>">
              <i class="fa fa-calendar"></i> <span>Contact</span>
            </a>
          </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-files-o"></i>
            <span>Header</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
          <li><a href="<?php echo e(route('header.create')); ?>"><i class="fa fa-circle-o"></i> Header Add</a></li>
            <li><a href="<?php echo e(route('header.index')); ?>"><i class="fa fa-circle-o"></i> Header List</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-files-o"></i>
            <span>Team</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
          <li><a href="<?php echo e(route('team.create')); ?>"><i class="fa fa-circle-o"></i> Team Add</a></li>
            <li><a href="<?php echo e(route('team.index')); ?>"><i class="fa fa-circle-o"></i> Team List</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-files-o"></i>
            <span>Client</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
          <li><a href="<?php echo e(route('client.create')); ?>"><i class="fa fa-circle-o"></i> Client Add</a></li>
            <li><a href="<?php echo e(route('client.index')); ?>"><i class="fa fa-circle-o"></i> Client List</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-files-o"></i>
            <span>Banner</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
          <li><a href="<?php echo e(route('banner.create')); ?>"><i class="fa fa-circle-o"></i> Banner Add</a></li>
            <li><a href="<?php echo e(route('banner.index')); ?>"><i class="fa fa-circle-o"></i> Banner List</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-files-o"></i>
            <span>Portfolio</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
          <li><a href="<?php echo e(route('portfolio.create')); ?>"><i class="fa fa-circle-o"></i> Portfolio Add</a></li>
            <li><a href="<?php echo e(route('portfolio.index')); ?>"><i class="fa fa-circle-o"></i> Portfolio List</a></li>
          </ul>
        </li>
      </ul>
    </section>
  
  </aside><?php /**PATH C:\xampp\htdocs\ThemePixel\resources\views/backend/partials/aside.blade.php ENDPATH**/ ?>