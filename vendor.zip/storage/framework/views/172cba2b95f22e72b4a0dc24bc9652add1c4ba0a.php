<div class="sup_get_started_section">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6 col-xs-12 col-sm-12">
                <div class="sup_get_started_data">
                    <h2>Ready To Get Started?</h2>
                    <p>Welcome to Theme pixel BD., one of the best software companies in Bangladesh.</p>
                </div>
            </div>
            <div class="col-lg-5 col-md-5 col-xs-12 col-sm-12 pull-right">
                <div class="sup_mobile_img sup_mobile_img_small">
                    <img src="<?php echo e(asset('frontend/images/add_img2.png')); ?>" class="img-responsive wow fromleft" alt="">
                <a href="<?php echo e(route('contact')); ?>"><i class="icon-speech icons"></i><span>Contact Us</span></a>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="sup_follow_on_section">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 pull-right">
                <div class="row">
                    <div class="sup_followon">
                        <h5>Follow on </h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\ThemePixel\resources\views/frontend/main/getting.blade.php ENDPATH**/ ?>