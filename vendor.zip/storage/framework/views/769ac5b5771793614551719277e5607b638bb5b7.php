	<!-- jQuery 3 -->
	<script src="<?php echo e(asset('js/jquery-3.3.1.min.js')); ?>"></script>
	
	<!-- popper -->
	<script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
	
	<!-- Bootstrap v4.1.3.stable -->
	<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>

	<!-- SlimScroll -->
	<script src="<?php echo e(asset('js/jquery.slimscroll.min.js')); ?>"></script>
	
	<!-- FastClick -->
	<script src="<?php echo e(asset('js/fastclick.js')); ?>"></script>
	
	<!-- ThemePixel App -->
	<script src="<?php echo e(asset('js/template.js')); ?>"></script>
	
	<!-- ThemePixel for demo purposes -->
  <script src="<?php echo e(asset('js/demo.js')); ?>"></script>
  
	<!-- Select2 -->
  <script src="<?php echo e(asset('js/select2.full.js')); ?>"></script>
  

	<!-- ThemePixel for advanced form element -->
  <script src="<?php echo e(asset('js/advanced-form-element.js')); ?>"></script>

<!-- DataTables -->
	<script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
	<script src="<?php echo e(asset('js/dataTables.bootstrap.min.js')); ?>"></script>
				
<!-- This is data table -->
	<script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
	   	
<!-- ThemePixel for Data Table -->
	<script src="<?php echo e(asset('js/data-table.js')); ?>"></script>

<?php /**PATH C:\xampp\htdocs\ThemePixel\resources\views/backend/partials/js.blade.php ENDPATH**/ ?>