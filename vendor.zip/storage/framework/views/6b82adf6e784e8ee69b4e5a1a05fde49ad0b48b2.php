<div class="sup_counter_section2">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                <div class="sup_counter sup_toppadder70">
                    <span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="19px" height="18px" viewBox="0 0 19 18" enable-background="new 0 0 19 18" xml:space="preserve">
                    <path fill-rule="evenodd" clip-rule="evenodd" fill="#31AAE1" d="M0,17.999v-16.2h9.5v1.199H1.188v13.8h16.625V8.398H19v9.601H0z
                         M17.885,4.52l-3.359-3.394l0.42-0.425c0.448-0.453,1.045-0.703,1.679-0.703c0.636,0,1.231,0.25,1.681,0.703
                        C18.752,1.152,18.999,1.755,19,2.396c0,0.642-0.246,1.245-0.695,1.698L17.885,4.52z M17.465,1.551c-0.3-0.303-0.75-0.42-1.148-0.313
                        l1.456,1.471c0.026-0.101,0.04-0.205,0.04-0.313C17.813,2.076,17.689,1.776,17.465,1.551z M14.525,2.823L8.811,8.598l1.12,0.565
                        l0.56,1.131l5.715-5.774l0.84,0.849l-6.88,6.952l-1.119-2.263L6.805,8.927l6.881-6.953L14.525,2.823z M9.175,13.231l-4.905,1.651
                        l1.635-4.957l1.125,0.38l-0.883,2.68l2.651-0.893L9.175,13.231z"/>
                    </svg></span>
                    <h1 class="timer" data-from="0" data-to="4005" data-speed="2000" data-refresh-interval="10">4005</h1>
                    <div class="sup_title_border"></div>
                    <p>DESIGNS CREATED</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                <div class="sup_counter sup_toppadder70">
                    <span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="20px" height="20px" viewBox="0 0 20 20" enable-background="new 0 0 20 20" xml:space="preserve">
                    <path fill-rule="evenodd" clip-rule="evenodd" fill="#31AAE1" d="M16.265,18.748v-1.25h2.3l-0.463-3.248l-1.992-0.537l0.311-1.211
                        l2.797,0.745L20,18.748H16.265z M14.396,11.248v-1.25c1.717,0,3.113-1.401,3.113-3.125c0-1.723-1.396-3.125-3.113-3.125v-1.25
                        c2.403,0,4.358,1.963,4.358,4.375S16.8,11.248,14.396,11.248z M0,19.998l0.769-6.514l2.936-0.955l0.384,1.188l-2.177,0.709
                        l-0.51,4.321h12.295l-0.51-4.321l-2.178-0.709l0.384-1.188l2.936,0.955l0.77,6.514H0z M7.549,11.248
                        c-3.09,0-5.604-2.523-5.604-5.625s2.514-5.625,5.604-5.625c3.089,0,5.603,2.523,5.603,5.625S10.639,11.248,7.549,11.248z
                         M7.549,1.248c-2.403,0-4.359,1.963-4.359,4.375c0,2.413,1.956,4.376,4.359,4.376c2.403,0,4.357-1.963,4.357-4.376
                        C11.906,3.211,9.952,1.248,7.549,1.248z"/>
                    </svg></span>
                    <h1 class="timer" data-from="0" data-to="1980" data-speed="2000" data-refresh-interval="10">1980</h1>
                    <div class="sup_title_border"></div>
                    <p>CLIENTS WORLDWIDE</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                <div class="sup_counter sup_toppadder70">
                    <span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="20px" height="20px" viewBox="0 0 20 20" enable-background="new 0 0 20 20" xml:space="preserve">
                    <path fill-rule="evenodd" clip-rule="evenodd" fill="#31AAE1" d="M14.691,10.632l-0.939-0.883l4.943-4.933V1.291h-3.539
                        l-4.889,4.933L9.383,5.3L14.691,0H20v5.333L14.691,10.632z M7.134,12.082l3.029-3.126l0.899,0.869l-3.043,3.14l2.795,2.79l1.62-4.55
                        l1.18,0.418l-2.283,6.413L1.966,8.689l6.425-2.28L8.81,7.586L4.251,9.204L7.134,12.082z M4.314,13.389l-1.849,4.149l4.157-1.845
                        l0.508,1.142L0,20l3.171-7.118L4.314,13.389z"/>
                    </svg></span>
                    <h1 class="timer" data-from="0" data-to="3640" data-speed="2000" data-refresh-interval="10">3640</h1>
                    <div class="sup_title_border"></div>
                    <p>PROJECTS DELIVERED</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                <div class="sup_counter sup_toppadder70">
                    <span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="20px" height="15px" viewBox="0 0 20 15" enable-background="new 0 0 20 15" xml:space="preserve">
                    <path fill-rule="evenodd" clip-rule="evenodd" fill="#31AAE1" d="M18.129,6.261h-0.649V5.008h0.649c0.344,0,0.625-0.281,0.625-0.627
                        V3.129c0-0.347-0.281-0.628-0.625-0.628h-0.649V1.248h0.649c1.033,0,1.875,0.843,1.875,1.881v1.268
                        C19.995,5.426,19.157,6.261,18.129,6.261z M8.121,12.527c-4.48,0-8.125-3.759-8.125-8.381v-4.151h16.25v4.151
                        C16.246,8.769,12.602,12.527,8.121,12.527z M14.996,1.248H1.246v2.898c0,3.93,3.084,7.128,6.875,7.128s6.875-3.198,6.875-7.128
                        V1.248z M2.504,4.146V3.129h1.25v1.018c0,2.548,1.962,4.621,4.375,4.621v1.252C5.027,10.02,2.504,7.386,2.504,4.146z M13.121,15.002
                        h-10v-1.253h10V15.002z"/>
                    </svg></span>
                    <h1 class="timer" data-from="0" data-to="2060" data-speed="2000" data-refresh-interval="10">2060</h1>
                    <div class="sup_title_border"></div>
                    <p>CUPS OF COFFEE</p>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\ThemePixel\resources\views/frontend/partials/counter.blade.php ENDPATH**/ ?>