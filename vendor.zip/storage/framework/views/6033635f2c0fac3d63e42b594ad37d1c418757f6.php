<div class="sup_transparent sup_toppadder100 sup_bottompadder100">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-10 col-sm-12 col-xs-12 col-lg-offset-2 col-md-offset-1 col-sm-offset-0 col-xs-offset-0">
                <div class="sup_heading text-center sup_bottompadder70">
                    <h4>Our team</h4>
                    <div class="sup_title_border"></div>
                    <p>Bras urna felis accumsan at ultrde cesid posuere masa socis nautoque penat bus maecenas ultrices sed ipsum lorem dolor sit amet sed ipsum consectetur adipisicing elit sed do eiusmod tempor incididunt</p>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 sup_bottompadder60">
                <div class="sup_teammember frombottom wow" data-wow-duration="0.5s">
                    <img src="<?php echo e(asset('frontend/images/member1.jpg')); ?>" class="img-responsive" alt="">
                    <div class="sup_team_overlay">
                        <div class="sup_team_plus"><a class="fancybox" data-fancybox-group="team" href="<?php echo e(asset('frontend/images/member1.jpg')); ?>" title="Richard Smith"><i class="fa fa-plus" aria-hidden="true"></i></a>
                        </div>
                        <div class="sup_team_detail">
                            <h5>Richard Smith</h5>
                            <p>Ceo & Co-Founder </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 sup_bottompadder60">
                <div class="sup_teammember frombottom wow" data-wow-duration="0.6s">
                    <img src="<?php echo e(asset('frontend/images/member2.jpg')); ?>" class="img-responsive" alt="">
                    <div class="sup_team_overlay">
                        <div class="sup_team_plus"><a class="fancybox" data-fancybox-group="team" href="<?php echo e(asset('frontend/images/member2.jpg')); ?>" title="Richard Smith"><i class="fa fa-plus" aria-hidden="true"></i></a>
                        </div>
                        <div class="sup_team_detail">
                            <h5>Richard Smith</h5>
                            <p>Ceo & Co-Founder </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 sup_bottompadder60">
                <div class="sup_teammember frombottom wow" data-wow-duration="0.7s">
                    <img src="<?php echo e(asset('frontend/images/member3.jpg')); ?>" class="img-responsive" alt="">
                    <div class="sup_team_overlay">
                        <div class="sup_team_plus"><a class="fancybox" data-fancybox-group="team" href="<?php echo e(asset('frontend/images/member3.jpg')); ?>" title="Richard Smith"><i class="fa fa-plus" aria-hidden="true"></i></a>
                        </div>
                        <div class="sup_team_detail">
                            <h5>Richard Smith</h5>
                            <p>Ceo & Co-Founder </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 sup_bottompadder60">
                <div class="sup_teammember frombottom wow" data-wow-duration="0.8s">
                    <img src="<?php echo e(asset('frontend/images/member4.jpg')); ?>" class="img-responsive" alt="">
                    <div class="sup_team_overlay">
                        <div class="sup_team_plus"><a class="fancybox" data-fancybox-group="team" href="<?php echo e(asset('frontend/images/member4.jpg')); ?>" title="Richard Smith"><i class="fa fa-plus" aria-hidden="true"></i></a>
                        </div>
                        <div class="sup_team_detail">
                            <h5>Richard Smith</h5>
                            <p>Ceo & Co-Founder </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\ThemePixel\resources\views/frontend/partials/team.blade.php ENDPATH**/ ?>