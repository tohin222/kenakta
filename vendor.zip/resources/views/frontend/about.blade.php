<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Theme Pixel</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="">
    <meta name="MobileOptimized" content="320">

    @include('frontend.partials.css')
</head>

<body>
    <div class="sup_topborder"></div>
    @include('frontend.partials.header')
    @include('frontend.partials.navbar2')
    <div class="sup_breadcrumb_section">
        <div class="sup_overlay"></div>
        <div class="sup_blue_overlay"></div>
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <div class="sup_pagetitle sup_toppadder90 sup_bottompadder90">
                        <h2>About Us</h2>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <div class="sup_breadcrumb_div sup_toppadder90 sup_bottompadder90">
                        <ol class="breadcrumb">
                            <li><a href="index.html">Home</a>
                            </li>
                            <li class="active">About us</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="sup_transparent sup_toppadder100 sup_bottompadder100">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-md-10 col-sm-12 col-xs-12 col-lg-offset-2 col-md-offset-1 col-sm-offset-0 col-xs-offset-0">
                    <div class="sup_heading text-center sup_bottompadder70">
                        <h4>ABout us</h4>
                        <div class="sup_title_border"></div>
                        <p>Welcome to Theme pixel BD., one of the best software companies in Bangladesh.</p>
                    </div>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div id="sup_aboutus_slider" class="carousel slide sup_aboutus_slider" data-ride="carousel">
                        <!-- Indicators -->


                        <!-- Wrapper for slides -->
                        <div class="carousel-inner" role="listbox">
                            <div class="item active">
                                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <div class="sup_about_slider-img">
                                        <img src="{{asset('frontend/images/about_us_slider1.jpg')}}" alt="..." class="img-responsive">
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <div class="sup_about_data">
                                        <h4 class="javascript:;">WE ARE Theme Pixel</h4>
                                        <div class="sup_title_border"></div>
                                        <p class="">Theme Pixel has highly skilled engineers with excellent technical knowledge and experience in using the latest software standards, tools, platforms, frameworks, and technologies. We want you to be completely satisfied with our services. We will do whatever it takes to make you happy.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <div class="sup_about_slider-img">
                                        <img src="{{asset('frontend/images/about_us_slider2.jpg')}}" alt="..." class="img-responsive">
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <div class="sup_about_data">
                                        <h4 class="javascript:;">WE ARE Theme Pixel</h4>
                                        <div class="sup_title_border"></div>
                                        <p class="">Theme Pixel has highly skilled engineers with excellent technical knowledge and experience in using the latest software standards, tools, platforms, frameworks, and technologies. We want you to be completely satisfied with our services. We will do whatever it takes to make you happy.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <div class="sup_about_slider-img">
                                        <img src="{{asset('frontend/images/about_us_slider3.jpg')}}" alt="..." class="img-responsive">
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <div class="sup_about_data">
                                        <h4 class="javascript:;">WE ARE Theme Pixel</h4>
                                        <div class="sup_title_border"></div>
                                        <p class="">Theme Pixel has highly skilled engineers with excellent technical knowledge and experience in using the latest software standards, tools, platforms, frameworks, and technologies. We want you to be completely satisfied with our services. We will do whatever it takes to make you happy.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <div class="sup_about_slider-img">
                                        <img src="{{asset('frontend/images/about_us_slider4.jpg')}}" alt="..." class="img-responsive">
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <div class="sup_about_data">
                                        <h4 class="javascript:;">WE ARE Theme Pixel</h4>
                                        <div class="sup_title_border"></div>
                                        <p class="">Theme Pixel has highly skilled engineers with excellent technical knowledge and experience in using the latest software standards, tools, platforms, frameworks, and technologies. We want you to be completely satisfied with our services. We will do whatever it takes to make you happy.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <div class="sup_about_slider-img">
                                        <img src="{{asset('frontend/images/about_us_slider5.jpg')}}" alt="..." class="img-responsive">
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                                    <div class="sup_about_data">
                                        <h4 class="javascript:;">WE ARE Theme Pixel</h4>
                                        <div class="sup_title_border"></div>
                                        <p class="">Theme Pixel has highly skilled engineers with excellent technical knowledge and experience in using the latest software standards, tools, platforms, frameworks, and technologies. We want you to be completely satisfied with our services. We will do whatever it takes to make you happy.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <ol class="carousel-indicators">
                            <li data-target="#sup_aboutus_slider" data-slide-to="0" class="active"><img src="{{asset('frontend/images/about_us_slider_thumb1.jpg')}}" alt="">
                                <div class="sup_overlay"></div>
                            </li>
                            <li data-target="#sup_aboutus_slider" data-slide-to="1"><img src="{{asset('frontend/images/about_us_slider_thumb2.jpg')}}" alt="">
                                <div class="sup_overlay"></div>
                            </li>
                            <li data-target="#sup_aboutus_slider" data-slide-to="2"><img src="{{asset('frontend/images/about_us_slider_thumb3.jpg')}}" alt="">
                                <div class="sup_overlay"></div>
                            </li>
                            <li data-target="#sup_aboutus_slider" data-slide-to="3"><img src="{{asset('frontend/images/about_us_slider_thumb4.jpg')}}" alt="">
                                <div class="sup_overlay"></div>
                            </li>
                            <li data-target="#sup_aboutus_slider" data-slide-to="4"><img src="{{asset('frontend/images/about_us_slider_thumb5.jpg')}}" alt="">
                                <div class="sup_overlay"></div>
                            </li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>
  
  

    
    @include('frontend.partials.footer')
    @include('frontend.partials.js')
</body>

</html>