{{-- @extends('frontend.master') --}}
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Theme Pixel</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="author" content="">
    <meta name="MobileOptimized" content="320">

    @include('frontend.partials.css')
</head>

<body>
    <div class="sup_topborder"></div>
    @include('frontend.partials.header')
    @include('frontend.partials.navbar')
    @include('frontend.partials.slider')
    @include('frontend.main.analyze')
    @include('frontend.partials.banner')
    @include('frontend.main.feature')
    @include('frontend.main.client')
    @include('frontend.main.portfolio')
    {{-- @include('frontend.main.brag') --}}
    @include('frontend.main.counter')
    @include('frontend.main.team')
    @include('frontend.main.work')
    @include('frontend.main.getting')
    @include('frontend.partials.footer')
    @include('frontend.partials.js')
</body>

</html>