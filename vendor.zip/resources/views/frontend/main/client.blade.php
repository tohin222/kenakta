
<div class="sup_testimonial_section sup_testimonial_section2 sup_toppadder100 sup_bottompadder100">
    <div class="sup_overlay"></div>
    <div class="container">
        <div class="row myOwl">
            @foreach ($myclients as $client)
                <div class="item">
                    <div class="col-lg-6 col-md-8 col-sm-12 col-xs-12 col-lg-offset-3 col-md-offset-2 col-sm-offset-0 col-xs-offset-0">
                        <div class="sup_testimonial_heading">
                            <h3>What Our Client Say</h3>
                        </div>
                    </div>
                    <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 col-lg-offset-2 col-md-offset-2 col-sm-offset-0 col-xs-offset-0">
                        <div class="sup_testimonial_detail">
                        <p>{{$client->comment}}</p>
                        <span>{{$client->name}}</span>
                        </div>
                    </div>
                </div>
            @endforeach
            
           

            
        </div>
    </div>
</div>
