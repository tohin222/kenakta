<div id="team" class="sup_transparent sup_toppadder100 sup_bottompadder100">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-10 col-sm-12 col-xs-12 col-lg-offset-2 col-md-offset-1 col-sm-offset-0 col-xs-offset-0">
                <div class="sup_heading text-center sup_bottompadder70">
                    <h4>Our team</h4>
                    <div class="sup_title_border"></div>
                    <p>Welcome to Theme pixel BD., one of the best software companies in Bangladesh.</p>
                </div>
            </div>
            @foreach ($teams as $team)
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 sup_bottompadder60">
                <div class="sup_teammember frombottom wow" data-wow-duration="0.5s">
                    <img src="{{asset('/storage')}}/{{$team->image}}" class="img-responsive" alt="">
                    <div class="sup_team_overlay">
                        <div class="sup_team_plus"><a class="fancybox" data-fancybox-group="team" href="{{asset('/storage')}}/{{$team->image}}" title="{{$team->name}}"><i class="fa fa-plus" aria-hidden="true"></i></a>
                        </div>
                        <div class="sup_team_detail">
                        <h5>{{$team->name}}</h5>
                            <p>{{$team->post}}</p>
                        </div>
                    </div>
                </div>
            </div>
            @endforeach
           
            
        </div>
    </div>
</div>