<div class="sup_transparent sup_toppadder100 sup_bottompadder100">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-10 col-sm-12 col-xs-12 col-lg-offset-2 col-md-offset-1 col-sm-offset-0 col-xs-offset-0">
                <div class="sup_heading text-center sup_bottompadder70">
                    <h4>WE HAVE WORKED WITH</h4>
                    <div class="sup_title_border"></div>
                    <p>Welcome to Theme pixel BD., one of the best software companies in Bangladesh.</p>
                </div>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="sup_client_slider">
                    <div id="sup_client" class="owl-carousel owl-theme">
                        <div class="item">
                            <div class="sup_client">
                                <img src="{{asset('frontend/images/Untitled-1.jpg')}}" class="img-responsive" alt="">
                            </div>
                        </div>
                        <div class="item">
                            <div class="sup_client">
                                <img src="{{asset('frontend/images/Untitled-2.jpg')}}" class="img-responsive" alt="">
                            </div>
                        </div>
                        <div class="item">
                            <div class="sup_client">
                                <img src="{{asset('frontend/images/Untitled-1.jpg')}}" class="img-responsive" alt="">
                            </div>
                        </div>
                        <div class="item">
                            <div class="sup_client">
                                <img src="{{asset('frontend/images/Untitled-2.jpg')}}" class="img-responsive" alt="">
                            </div>
                        </div>
                        <div class="item">
                            <div class="sup_client">
                                <img src="{{asset('frontend/images/Untitled-1.jpg')}}" class="img-responsive" alt="">
                            </div>
                        </div>
                        <div class="item">
                            <div class="sup_client">
                                <img src="{{asset('frontend/images/Untitled-2.jpg')}}" class="img-responsive" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>