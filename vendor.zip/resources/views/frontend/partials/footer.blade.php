<div class="sup_footer">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 col-lg-push-6 col-md-push-6 col-sm-push-0 col-xs-push-0 sup_leftpadder0">
                <div>
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d233668.38703692693!2d90.27923991057244!3d23.780573258035957!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755b8b087026b81%3A0x8fa563bbdd5904c2!2z4Kai4Ka-4KaV4Ka-!5e0!3m2!1sbn!2sbd!4v1578760753130!5m2!1sbn!2sbd" width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
                </div>
                {{-- <div id="mapdiv"></div> --}}
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 col-lg-pull-6 col-md-pull-6 col-sm-pull-0 col-xs-pull-0">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 sup_toppadder80 sup_bottompadder40">
                        <div class="sup_footer_widget">
                            <a href="{{route('banner')}}"><img src="{{asset('frontend/images/footer_logo.png')}}" class="img-responsive" alt="">
                            </a>
                            <p>Theme Pixel has highly skilled engineers with excellent technical knowledge and experience in using the latest software standards, tools, platforms, frameworks, and technologies. We want you to be completely satisfied with our services. We will do whatever it takes to make you happy. </p>
                          
                       
                        </div>
                    </div>
                   
                </div>
            </div>
        </div>
    </div>
</div>
<div class="sup_bottom_footer">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <div class="sup_copyright">
                    <p>Copyright &copy; 2019. Theme Pixel Author. </p>
                    <a href="{{route('banner')}}" class="sup_gototop"><i class="fa fa-arrow-up" aria-hidden="true"></i></a>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <div class="sup_footer_sociallink">
                    <ul>
                        @foreach ($headers as $header)
                            <li><a href="{{$header->facebook}}" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                            </li>
                            <li><a href="{{$header->twitter}}" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                            </li>
                            <li><a href="{{$header->pinterest}}" target="_blank"><i class="fa fa-pinterest-p" aria-hidden="true"></i></a>
                            </li>
                            <li><a href="{{$header->linkdin}}" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
                            </li>
                            <li><a href="{{$header->google}}" target="_blank"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
                            </li>
                            @break
                        @endforeach
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="sup_blackbg2"></div>
</div>