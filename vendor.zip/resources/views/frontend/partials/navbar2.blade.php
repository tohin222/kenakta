<div class="sup_mainheader">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <nav class="navbar navbar-default sup_header">
                    <div class="row">
                        <div class="col-lg-9 col-md-9 col-sm-12 col-xs-12">
                            <div class="row">
                                <div class="sup_menumain_div">
                                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#sup_menu" aria-expanded="false">
                                        <span class="sr-only">Toggle navigation</span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                        <span class="icon-bar"></span>
                                    </button>
                                    <div class="collapse navbar-collapse sup_mainmenu" id="sup_menu">
                                        <ul class="nav navbar-nav"> 
                                            <li><a href="{{route('banner')}}">Home</a>
                                            </li>
                                        <li><a href="{{route('about')}}">About Us</a>
                                            </li>
                                             <li><a href="{{route('contact')}}">Contact Us</a></li>
                                        </ul>
                                              
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
                            <div class="sup_right_link">
                                <ul>
                                    <li id="top-search"><a href="javascript:;"><i class="fa fa-search" aria-hidden="true"></i></a>
                                    </li>
                                   
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div id="top-search-wrap">
                        <form class="form-inline">
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon"><i class="icon-magnifier icons"></i>
                                    </div>
                                    <input type="text" placeholder="Search.....">
                                </div>
                            </div>
                            <i id="top-search-close">&times;</i>
                        </form>
                    </div>
                </nav>
            </div>
        </div>
    </div>
</div>