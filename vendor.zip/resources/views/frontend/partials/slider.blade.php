<div class="sup_slider_second">
    <div id="owl-demo" class="owl-carousel owl-theme">
       @foreach ($banners as $banner)
       <div class="item">
        <div class="sup_bannerdata">
            <img src="{{asset('/storage')}}/{{$banner->image}}" alt="">
            <div class="sup_banner">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="sup_banner_content">
                                <h1>{{$banner->title}}</h1>
                                <p>{{$banner->content}} </p>
                                {{-- <a href="about_us.html" class="sup_btn sup_blue_btn">Learn More <span><i class="fa fa-angle-right" aria-hidden="true"></i></span></a> --}}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
       @endforeach
    </div>
</div>