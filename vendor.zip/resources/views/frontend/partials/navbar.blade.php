<div class="sup_mainheader sup_index2_header">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="sup_menudiv">
                    <div class="sup_right_link">
                        <div class="sup_fixed_logo">
                            <a href="index.html"><img src="{{asset('frontend/images/logo.png')}}" class="img-responsive" alt="Spped-Up">
                            </a>
                        </div>
                        <ul>
                            <li><a href="javascript:;" class="sup_menubtn"><i class="fa fa-bars" aria-hidden="true"></i></a>
                            <div class="sup_mainmenu" id="sup_menu">
                                <ul class="nav navbar-nav">
                                    <li><a href="{{route('banner')}}">Home</a></li>
                                    <li><a href="#team">Team</a></li>
                                    <li><a href="#portfolio">Portfolio</a></li>
                                    <li><a href="{{route('about')}}">About Us</a></li>
                                     <li><a href="{{route('contact')}}">Contact Us</a></li>
                                </ul>
                            </div>
                            </li>
                            <li id="top-search"><a href="javascript:;"><i class="fa fa-search" aria-hidden="true"></i></a>
                            </li>
                            {{-- <li><a href="javascript:;"><i class="fa fa-shopping-cart" aria-hidden="true"></i><span>5</span></a>
                            </li> --}}
                        </ul>
                        <div id="top-search-wrap">
                            <div class="container">
                                <form class="form-inline">
                                    <div class="form-group">
                                        <div class="input-group">
                                            <div class="input-group-addon"><i class="icon-magnifier icons"></i>
                                            </div>
                                            <input type="text" placeholder="Search.....">
                                        </div>
                                    </div>
                                    <i id="top-search-close">&times;</i>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>