<script src="{{asset('frontend/js/jquery-1.12.3.min.js')}}" type="text/javascript"></script>
    <script src="{{asset('frontend/js/bootstrap.js')}}" type="text/javascript"></script>
    <script src="{{asset('frontend/js/wow.js')}}" type="text/javascript"></script>
    <script src="{{asset('frontend/js/plugins/owl/owl.carousel.js')}}" type="text/javascript"></script>
    <script src="{{asset('frontend/js/plugins/mesonary/FilterableProductGrid/js/modernizr.custom.js')}}" type="text/javascript"></script>
    <script src="{{asset('frontend/js/plugins/owl/owl.carousel.js')}}" type="text/javascript"></script>
    <script src="{{asset('frontend/js/plugins/fancybox/jquery.fancybox.pack.js')}}" type="text/javascript"></script>
    <script src="{{asset('frontend/js/plugins/fancybox/jquery.fancybox.js')}}" type="text/javascript"></script>
    <script src="{{asset('frontend/js/plugins/countto/jquery.appear.js')}}" type="text/javascript"></script>
    <script src="{{asset('frontend/js/plugins/countto/jquery.countTo.js')}}" type="text/javascript"></script>
    <script src="{{asset('frontend/js/jquery.mixitup.js')}}" type="text/javascript"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=&amp;sensor=false"></script>
    <script src="{{asset('frontend/js/custom.js')}}" type="text/javascript"></script>
