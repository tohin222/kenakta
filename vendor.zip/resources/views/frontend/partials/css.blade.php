<link href="{{asset('frontend/css/main.css')}}" rel="stylesheet" type="text/css">
<link rel="shortcut icon" type="image/png" href="{{asset('frontend/images/favicon.png')}}">