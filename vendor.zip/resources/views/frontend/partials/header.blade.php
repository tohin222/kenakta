<div class="sup_topheader sup_toppadder40 sup_bottompadder40">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                <div class="sup_phoneno">
                    <ul>
                        @foreach ($headers as $header)
                    <li><a href="javascript:;"><span><i class="fa fa-phone" aria-hidden="true"></i></span>{{$header->number}}</a>
                            </li>
                            @break
                        @endforeach
                    </ul>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 text-center">
                <div class="sup_logo">
                    <a href="{{route('banner')}}"><img src="{{asset('frontend/images/logo.png')}}" class="img-responsive" alt="Theme-Pixel">
                    </a>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                <div class="sup_social_link">
                    <ul>
                        @foreach ($headers as $header)
                                <li><a href="{{$header->facebook}}" target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                                </li>
                                <li><a href="{{$header->twitter}}" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                                </li>
                                <li><a href="{{$header->pinterest}}" target="_blank"><i class="fa fa-pinterest-p" aria-hidden="true"></i></a>
                                </li>
                                <li><a href="{{$header->linkdin}}" target="_blank"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
                                </li>
                                <li><a href="{{$header->google}}" target="_blank"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
                                </li>
                            @break
                        @endforeach
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>