@extends('backend.layouts.master')
@section('contains')
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Basic mSells
    </h1>
  </section>

  <!-- Main content -->
  <section class="content">

    <!-- SELECT2 EXAMPLE -->
    <div class="box box-default">

      <!-- /.box-header -->
      <div class="box-body">
        <div class="row">
          <div class="col-md-6 col-12">
            @if (session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
          @endif
            <form action="{{route('header.store')}}" method="post" enctype="multipart/form-data">
              @csrf
                  <div class="form-group">
                    <label for="inputEmail4">Facebook</label>
                    <input type="text" class="form-control" name="facebook">
                  </div>
                  <div class="form-group">
                    <label for="inputEmail4">Linkdin</label>
                    <input type="text" class="form-control" name="linkdin">
                  </div>
                  <div class="form-group">
                    <label for="inputEmail4">Twitter</label>
                    <input type="text" class="form-control" name="twitter">
                  </div>
                  <div class="form-group">
                    <label for="inputEmail4">Pinterest</label>
                    <input type="text" class="form-control" name="pinterest">
                  </div>
                  <div class="form-group">
                    <label for="inputEmail4">Google+</label>
                    <input type="text" class="form-control" name="google">
                  </div>
                  <div class="form-group">
                    <label for="inputEmail4">Mobile Number</label>
                    <input type="text" class="form-control" name="number">
                  </div>
                <button type="submit" class="btn btn-primary">Add</button>
              </form>
          </div>
        </div>
        <!-- /.row -->
      </div>
      <!-- /.box-body -->
    </div>
    <!-- /.box -->
    

  </section>
@endsection