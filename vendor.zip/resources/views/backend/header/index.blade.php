@extends('backend.layouts.master')
@section('contains')
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Basic mSells
    </h1>
  </section>

  <!-- Main content -->
  <section class="content">

    <!-- SELECT2 EXAMPLE -->
    <div class="box box-default">

      <!-- /.box-header -->
      <div class="box-body">
        <div class="row">
          <div class="col-md-12 col-12">
            @if (session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
          @endif
                <table class="table table-hover table-responsive">
                  <thead>
                    <tr>
                      <th scope="col">Action</th>
                      <th scope="col">Facebook</th>
                      <th scope="col">Linkdin</th>
                      <th scope="col">twitter</th>
                      <th scope="col">Linkdin</th>
                      <th scope="col">pinterest</th>
                      <th scope="col">google</th>
                      <th scope="col">number</th>
                      <th scope="col">Image</th>
                     
                    </tr>
                  </thead>
                  <tbody>
                    @foreach ($headers as $header)
                    <tr>
                      <td>
                        <a class="btn btn-warning" href="{{ route('header.edit', $header->id) }}">edit</a>
                        <br><br>
                        <form action="{{url('header', [$header->id])}}" method="POST">
                          {{method_field('DELETE')}}
                          @csrf
                          <input type="submit" class="btn btn-danger" value="Delete"/>
                       </form>
                        </td>
                    <td>{{$header->facebook}}</td>
                      <td>{{$header->linkdin}}</td>
                      <td>{{$header->twitter}}</td>
                      <td>{{$header->pinterest}}</td>
                      <td>{{$header->google}}</td>
                      <td>{{$header->number}}</td>
                      <td> 
                      <img src="{{asset('/storage')}}/{{$header->image}}" alt="" height="80" width="140">
                      </td>

                    </tr>
                    @endforeach
                   
                   
                  </tbody>
                </table>
          </div>
        </div>
        <!-- /.row -->
      </div>
      <!-- /.box-body -->
    </div>
    <!-- /.box -->
    

  </section>
@endsection