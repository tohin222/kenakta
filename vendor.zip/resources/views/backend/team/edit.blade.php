@extends('backend.layouts.master')
@section('contains')
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Edit
    </h1>
  </section>

  <!-- Main content -->
  <section class="content">

    <!-- SELECT2 EXAMPLE -->
    <div class="box box-default">

      <!-- /.box-header -->
      <div class="box-body">
        <div class="row">
          <div class="col-md-6 col-12">
            @if (session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
          @endif
            <form action="{{route('team.update',$team->id)}}" method="post" enctype="multipart/form-data">
                @csrf
                @method('PUT')
                  <div class="form-group">
                    <label for="inputEmail4">Name</label>
                  <input type="hidden" class="form-control" name="id" value="{{$team->id}}">
                    <input type="text" class="form-control" name="name" value="{{$team->name}}">
                  </div>
                  <div class="form-group">
                    <label for="inputEmail4">Post</label>
                    <input type="text" class="form-control" name="post" value="{{$team->post}}">
                  </div>
                  <div class="form-group">
                    <label for="inputEmail4">Image Size: 280 X 420</label>
                    <input type="file" class="form-control" name="image">
                  </div>
                <button type="submit" class="btn btn-success">Update</button>
              </form>
          </div>
        </div>
        <!-- /.row -->
      </div>
      <!-- /.box-body -->
    </div>
    <!-- /.box -->
    

  </section>
@endsection