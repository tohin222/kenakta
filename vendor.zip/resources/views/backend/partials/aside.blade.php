<aside class="main-sidebar">
    <!-- sidebar -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="image float-left">
          <img src="{{asset('/images/user.png')}}" class="rounded" alt="User Image">
        </div>
        <div class="info float-left">
          <p>  {{Auth::user()->name}}</p>
          <a href="#"><i class="fa fa-circle text-success"></i>
            @php
                if(Auth::user()->role===1){
              echo "Admin";
              }
              else {
              echo "SalesMan";
              }
            @endphp
          </a>
        </div>
      </div>
      
      <!-- sidebar menu  -->
      <ul class="sidebar-menu" data-widget="tree">
        <li>
          <a href="{{route('home')}}">
            <i class="fa fa-calendar"></i> <span>Basic mSells</span>
          </a>
        </li>
        <li>
        <a href="{{route('profile')}}">
            <i class="fa fa-calendar"></i> <span>Profile</span>
          </a>
        </li>
        <li>
          <a href="{{route('backend_contact')}}">
              <i class="fa fa-calendar"></i> <span>Contact</span>
            </a>
          </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-files-o"></i>
            <span>Header</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
          <li><a href="{{route('header.create')}}"><i class="fa fa-circle-o"></i> Header Add</a></li>
            <li><a href="{{route('header.index')}}"><i class="fa fa-circle-o"></i> Header List</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-files-o"></i>
            <span>Team</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
          <li><a href="{{route('team.create')}}"><i class="fa fa-circle-o"></i> Team Add</a></li>
            <li><a href="{{route('team.index')}}"><i class="fa fa-circle-o"></i> Team List</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-files-o"></i>
            <span>Client</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
          <li><a href="{{route('client.create')}}"><i class="fa fa-circle-o"></i> Client Add</a></li>
            <li><a href="{{route('client.index')}}"><i class="fa fa-circle-o"></i> Client List</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-files-o"></i>
            <span>Banner</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
          <li><a href="{{route('banner.create')}}"><i class="fa fa-circle-o"></i> Banner Add</a></li>
            <li><a href="{{route('banner.index')}}"><i class="fa fa-circle-o"></i> Banner List</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-files-o"></i>
            <span>Portfolio</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
          <li><a href="{{route('portfolio.create')}}"><i class="fa fa-circle-o"></i> Portfolio Add</a></li>
            <li><a href="{{route('portfolio.index')}}"><i class="fa fa-circle-o"></i> Portfolio List</a></li>
          </ul>
        </li>
      </ul>
    </section>
  
  </aside>