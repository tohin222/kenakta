

<!-- Bootstrap v4.1.3.stable -->
<link rel="stylesheet" href="{{asset('css/bootstrap.css')}}">

<!-- Font Awesome -->
<link rel="stylesheet" href="{{asset('css/fontawesome/font-awesome.css')}}">

<!-- Theme style -->
<link rel="stylesheet" href="{{asset('css/master_style.css')}}">

<link rel="stylesheet" href="{{asset('css/_all-skins.css')}}">	

<link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">

<!-- bootstrap datepicker -->	
<link rel="stylesheet" href="{{asset('css/bootstrap-datepicker.min.css')}}">	
<!-- Select2 -->
<link rel="stylesheet" href="{{asset('css/select2.min.css')}}">

<!-- fullCalendar -->
<link rel="stylesheet" href="{{asset('css/fullcalendar.min.css')}}">
<link rel="stylesheet" href="{{asset('css/fullcalendar.print.min.css')}}" media="print">