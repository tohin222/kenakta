	<!-- jQuery 3 -->
	<script src="{{asset('js/jquery-3.3.1.min.js')}}"></script>
	
	<!-- popper -->
	<script src="{{asset('js/popper.min.js')}}"></script>
	
	<!-- Bootstrap v4.1.3.stable -->
	<script src="{{asset('js/bootstrap.min.js')}}"></script>

	<!-- SlimScroll -->
	<script src="{{asset('js/jquery.slimscroll.min.js')}}"></script>
	
	<!-- FastClick -->
	<script src="{{asset('js/fastclick.js')}}"></script>
	
	<!-- ThemePixel App -->
	<script src="{{asset('js/template.js')}}"></script>
	
	<!-- ThemePixel for demo purposes -->
  <script src="{{asset('js/demo.js')}}"></script>
  
	<!-- Select2 -->
  <script src="{{asset('js/select2.full.js')}}"></script>
  

	<!-- ThemePixel for advanced form element -->
  <script src="{{asset('js/advanced-form-element.js')}}"></script>

<!-- DataTables -->
	<script src="{{asset('js/jquery.dataTables.min.js')}}"></script>
	<script src="{{asset('js/dataTables.bootstrap.min.js')}}"></script>
				
<!-- This is data table -->
	<script src="{{asset('js/jquery.dataTables.min.js')}}"></script>
	   	
<!-- ThemePixel for Data Table -->
	<script src="{{asset('js/data-table.js')}}"></script>

