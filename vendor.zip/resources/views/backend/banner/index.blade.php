@extends('backend.layouts.master')
@section('contains')
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Basic mSells
    </h1>
  </section>

  <!-- Main content -->
  <section class="content">

    <!-- SELECT2 EXAMPLE -->
    <div class="box box-default">

      <!-- /.box-header -->
      <div class="box-body">
        <div class="row">
          <div class="col-md-12 col-12">
            @if (session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
          @endif
                <table class="table table-hover">
                  <thead>
                    <tr>
                      <th scope="col">#</th>
                      <th scope="col">Name</th>
                      <th scope="col">Content</th>
                      <th scope="col">Image</th>
                      <th scope="col">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    @foreach ($banners as $banner)
                    <tr>
                      <th scope="row">1</th>
                    <td>{{$banner->title}}</td>
                      <td>{{$banner->content}}</td>
                      <td> 
                      <img src="{{asset('/storage')}}/{{$banner->image}}" alt="" height="80" width="140">
                      </td>
                      <td>
                        <a class="btn btn-warning" href="{{ route('banner.edit', $banner->id) }}">edit</a>
                        <br><br>
                        <form action="{{url('banner', [$banner->id])}}" method="POST">
                          {{method_field('DELETE')}}
                          @csrf
                          <input type="submit" class="btn btn-danger" value="Delete"/>
                       </form>
                        </td>
                    </tr>
                    @endforeach
                   
                   
                  </tbody>
                </table>
          </div>
        </div>
        <!-- /.row -->
      </div>
      <!-- /.box-body -->
    </div>
    <!-- /.box -->
    

  </section>
@endsection