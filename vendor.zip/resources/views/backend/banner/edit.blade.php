@extends('backend.layouts.master')
@section('contains')
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Edit
    </h1>
  </section>

  <!-- Main content -->
  <section class="content">

    <!-- SELECT2 EXAMPLE -->
    <div class="box box-default">

      <!-- /.box-header -->
      <div class="box-body">
        <div class="row">
          <div class="col-md-6 col-12">
            @if (session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
          @endif
            <form action="{{route('banner.update',$banner->id)}}" method="post" enctype="multipart/form-data">
                @csrf
                @method('PUT')
                  <div class="form-group">
                    <label for="inputEmail4">Title</label>
                  <input type="hidden" class="form-control" name="id" value="{{$banner->id}}">
                    <input type="text" class="form-control" name="title" value="{{$banner->title}}">
                  </div>
                  <div class="form-group">
                    <label for="inputEmail4">Content</label>
                    <input type="text" class="form-control" name="content" value="{{$banner->content}}">
                  </div>
                  <div class="form-group">
                    <label for="inputEmail4">Image Size: 1920 X 700</label>
                    <input type="file" class="form-control" name="image">
                  </div>
                <button type="submit" class="btn btn-success">Update</button>
              </form>
          </div>
        </div>
        <!-- /.row -->
      </div>
      <!-- /.box-body -->
    </div>
    <!-- /.box -->
    

  </section>
@endsection