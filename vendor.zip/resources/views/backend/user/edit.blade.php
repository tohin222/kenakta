@extends('backend.layouts.master')
@section('contains')
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Edit
    </h1>
  </section>

  <!-- Main content -->
  <section class="content">

    <!-- SELECT2 EXAMPLE -->
    <div class="box box-default">

      <!-- /.box-header -->
      <div class="box-body">
        <div class="row">
          <div class="col-md-6 col-12">
            @if (session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
          @endif
          <form action="{{url('user/update')}}" method="post" enctype="multipart/form-data">
                @csrf
                  <div class="form-group">
                    <label for="inputEmail4">Name</label>
                  <input type="hidden" class="form-control" name="id" value="{{Auth::user()->id}}">
                    <input type="text" class="form-control" name="name" value="{{Auth::user()->name}}">
                  </div>
                  <div class="form-group">
                    <label for="inputEmail4">Email</label>
                    <input type="text" class="form-control" name="email" value="{{Auth::user()->email}}">
                  </div>
                  <div class="form-group">
                    <label for="inputEmail4">Old Password</label>
                    <input type="password" class="form-control" name="password" >
                  </div>
                  <div class="form-group">
                    <label for="inputEmail4">New Password</label>
                    <input type="password" class="form-control" name="new_password">
                  </div>
                <button type="submit" class="btn btn-success">Update</button>
              </form>
          </div>
        </div>
        <!-- /.row -->
      </div>
      <!-- /.box-body -->
    </div>
    <!-- /.box -->
    

  </section>
@endsection