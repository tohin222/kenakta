@extends('backend.layouts.master')
@section('contains')
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Basic mSells
    </h1>
  </section>

   <!-- Main content -->
   <section class="content">

    <div class="row">
      <div class="col-xl-12 col-lg-12">

        <!-- Profile Image -->
        <div class="box box-primary">
          <div class="box-body box-profile">
            <img class="profile-user-img rounded-circle img-fluid mx-auto d-block" src="{{asset('frontend/../../images/5.jpg')}}" alt="User profile picture">

            <h3 class="profile-username text-center"> {{Auth::user()->name}}</h3>

            <p class="text-muted text-center">Admin</p>
              
          <p class="text-center"><a class="btn btn-success" href="{{route('edit')}}">Edit</a></p>
          
            <div class="row">
                <div class="col-12">
                    <div class="profile-user-info text-center">
                      <p>Email address </p>
                      <h6 class="margin-bottom text-center">{{Auth::user()->email}}</h6>
                      <p>Phone</p>
                      <h6 class="margin-bottom text-center">+11 123 456 7890</h6> 
                      <p>Address</p>
                      <h6 class="margin-bottom text-center">123, Lorem Ipsum, Florida, USA</h6>
                      <p class="margin-bottom text-center">Social Profile</p>
                      <div class="user-social-acount">
                          <button class="btn btn-circle btn-social-icon btn-facebook"><i class="fa fa-facebook"></i></button>
                          <button class="btn btn-circle btn-social-icon btn-twitter"><i class="fa fa-twitter"></i></button>
                          <button class="btn btn-circle btn-social-icon btn-instagram"><i class="fa fa-instagram"></i></button>
                      </div>
                  </div>
               </div>
            </div>
          </div>
          <!-- /.box-body -->
        </div>
        <!-- /.box -->
      </div>
    </div>
    <!-- /.row -->

  </section>
  <!-- /.content -->
@endsection