@extends('backend.layouts.master')
@section('contains')
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
      Edit
    </h1>
  </section>

  <!-- Main content -->
  <section class="content">

    <!-- SELECT2 EXAMPLE -->
    <div class="box box-default">

      <!-- /.box-header -->
      <div class="box-body">
        <div class="row">
          <div class="col-md-6 col-12">
            @if (session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
          @endif
            <form action="{{route('portfolio.update',$portfolio->id)}}" method="post" enctype="multipart/form-data">
                @csrf
                @method('PUT')
                  <div class="form-group">
                    <label for="inputEmail4">Name</label>
                  <input type="hidden" class="form-control" name="id" value="{{$portfolio->id}}">
                    <input type="text" class="form-control" name="name" value="{{$portfolio->name}}">
                  </div>
                  <div class="form-group">
                    <label for="inputEmail4">Link</label>
                    <input type="text" class="form-control" name="link" value="{{$portfolio->link}}">
                  </div>
                  <div class="form-group">
                    <label for="inputEmail4">Class Name</label>
                    <input type="text" class="form-control" name="classname" value="{{$portfolio->classname}}">
                  </div>
                  <div class="form-group">
                    <label for="inputEmail4">Image Size: 280 X 420</label>
                    <input type="file" class="form-control" name="image">
                  </div>
                <button type="submit" class="btn btn-success">Update</button>
              </form>
          </div>
        </div>
        <!-- /.row -->
      </div>
      <!-- /.box-body -->
    </div>
    <!-- /.box -->
    

  </section>
@endsection